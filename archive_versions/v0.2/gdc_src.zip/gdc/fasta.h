/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _FASTA_H
#define _FASTA_H

#include "defs.h"
#include "bit_memory.h"
#include <iostream>
#include <vector>
using namespace std;

typedef enum {mode_fa_none, mode_fa_read, mode_fa_write, mode_fa_read_ra} t_fa_mode;

// ********************************************************************************************
class CFastaSequence {
public:
	uchar *raw_data;
	int32 *char_stat;
	uint32 size;
	string seq_name;
	uint32 line_len;
	uint32 start_pos;
	uchar eol_type;

public:
	CFastaSequence();
	CFastaSequence(uchar *_raw_data, string &_seq_name, uint32 _line_len, uint32 _start_pos, uint32 _size, uchar _eol_type);
	CFastaSequence(const CFastaSequence &x);
	~CFastaSequence();
};

// ********************************************************************************************
class CFastaFile {
	FILE *file;

public:
	int64 file_size;
	t_fa_mode mode;

	uchar *raw_data;
	int64 raw_data_pos;
	int64 trans_data_pos;
	int64 data_size;
	uchar *raw_data_ptr;
	uchar *trans_data_ptr;
	uchar *eof_data_ptr;

	vector<CFastaSequence> sequences;
	int32 char_stat[256];

	bool ReadSequence();
	bool WriteSequence(CFastaSequence &seq);

public:
	CFastaFile() {
		file     = NULL;
		mode     = mode_fa_none;
		raw_data = NULL;
	};

	~CFastaFile() {
		if(file)
			fclose(file);
		if(raw_data)
			delete[] raw_data;
	}

	bool Open(string file_name);
	bool Create(string file_name);
	bool Close();
	bool Read(vector<CFastaSequence> &_sequences);
	bool Write(vector<CFastaSequence> &_sequences);
	int64 GetFileSize() {return file_size;}
};

#endif
