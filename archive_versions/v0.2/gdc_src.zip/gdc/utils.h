/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _UTILS_H
#define _UTILS_H

#include "defs.h"
#include <vector>
#include <map>
#include <string>

using namespace std;

#define MIN(x, y)		((x) < (y) ? (x) : (y))
#define ABS(x)			((x) >= 0 ? (x) : -(x))
#define SIGN(x)			((x) >= 0 ? 1 : -1)

class CPackedBuffer
{
	vector<uchar> *raw_buf;
	vector<uint16> *packed_buf;
	uchar *raw_pbuf;
	uint16 *packed_pbuf;
	uint32 raw_pbuf_len;
	uint32 packed_pbuf_len;

	uint32 n_raw;
	uint32 n_packed;

	typedef struct {
		uint64 magic;
		uint64 shift;
	} t_magic_no;

	t_magic_no *magic_nos;

public:
	CPackedBuffer();
	~CPackedBuffer();

	void Init(uint32 _n_packed);

	void SetBufs(uint32 _n_raw, uint32 _n_packed, vector<uchar> *_raw_buf, vector<uint16> *_packed_buf);
	void SetBufs(uint32 _n_raw, uint32 _n_packed, uchar *_raw_pbuf, uint16 *_packed_pbuf, uint32 _raw_pbuf_len, uint32 _packed_pbuf_len);
	bool Encode();
	bool Decode();
	bool EncodeP(uchar *coding);
	bool DecodeP(uchar *alph);
};

uint32 int_log(uint32 x, uint32 base);

void log_stats(char *file_name, vector<int32> &vec);

void log_data(char *file_name, vector<uchar> &vec);
void log_data(char *file_name, vector<int32> &vec);
void log_stats(char *file_name, map<int, int> &mm);

void log_match(char *file_name, vector<uchar> &v_flag, vector<int32> &v_len, vector<uchar> &v_lit);
void report(string text, uint64 pos, uint64 size, bool new_line);
void report(string text, bool new_line);

#endif
