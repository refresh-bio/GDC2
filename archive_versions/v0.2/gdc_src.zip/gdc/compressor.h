/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _COMPRESSOR_H
#define _COMPRESSOR_H

#include "defs.h"
#include "hasher.h"
#include "ref.h"
#include "huffman.h"
#include "sequence.h"
#include "utils.h"
#include "fasta.h"

#include <vector>
#include <utility>
#include <string>

using namespace std;

typedef enum {gdc_compress, gdc_decompress, gdc_extract, gdc_none} t_gdc_mode;

struct CGDCSequenceDesc
{
	string file_name;
	int id;
	bool is_ref;
	uchar eol_type;
	vector<uint32> sizes;
	vector<string> seq_names;
	vector<uint32> line_lens;
	vector<uint32> start_poss;

	CGDCSequenceDesc()
	{
	};

	CGDCSequenceDesc(string _file_name, vector<CFastaSequence> &data, int _id, bool _is_ref)
	{
		file_name = _file_name;
		is_ref    = _is_ref;
		id		  = _id;

		sizes.clear();
		seq_names.clear();
		line_lens.clear();
		start_poss.clear();

		for(int i = 0; i < data.size(); ++i)
		{
			seq_names.push_back(data[i].seq_name);
			line_lens.push_back(data[i].line_len);
			if(i == 0)
				start_poss.push_back(0);
			else
				start_poss.push_back(start_poss.back() + sizes.back());
			sizes.push_back(data[i].size);
		}
		if(data.size())
			eol_type = data[0].eol_type; 
		else
			eol_type = 0x0a;
	};
};

struct CRefCollection 
{
	CReference *ref;
	uchar *seq_ref;
	uchar *comp_seq_ref;
	uint32 seq_ref_size;
	FILE *in;

	CRefCollection()
	{
		ref			 = NULL;
		seq_ref		 = NULL;
		comp_seq_ref = NULL;
		in           = NULL;
	};
};

class CGDC
{
	CHasher *hasher;
	vector<CRefCollection> Refs;
	vector<vector<CFastaSequence> > refs_data;

	vector<CGDCSequenceDesc> archive_contents;
	t_gdc_mode mode;
	
	int32 min_match_1st_len;
	int32 min_match_ext_len;
	int32 min_match_total_len;
	int32 min_aug_len;
	int32 hash_step;
	int32 hash_colisions;
	string archive_name, archive_names[3];
	uint32 ref_seq_no;
	int32 extr_col_id, extr_seq_id;
	int32 extr_from, extr_to;
	uint32 dif_block_size_exp;
	uint32 ref_block_size_exp;

	int verbose_level;
	int64 total_size;
	vector<uint32> dif_seq_pos;
	uint32 ref1st_seq_size;
	uint32 aug_seq_size;

	FILE *f_dif, *f_ref, *f_aug;
	vector<pair<pair<int, int>, CSequence*> > buf_dif_seq;

	uchar lit_coding[256];
	uchar alph[256];
	uint32 sigma;
	uint32 ref_mode;
	uchar compress_mode;

	uint32 _size_ref, _size_aug, _size_dif;

	char *PrepSeqName(char *seq_name, char *seq_name_pref, int id);
	void ClearBufDifSeq();

	bool SetNames();
	void FindAlphabet(vector<CFastaSequence> &data);

	bool AddCollectionRef1st(string &col_name, vector<CFastaSequence> &data);
	bool AddCollectionDif(string &col_name, vector<CFastaSequence> &data);
	bool AddCollectionRefAux(string &col_name, vector<CFastaSequence> &data);

	bool ReadCollectionRef1stDesc();
	bool ReadCollectionAugDesc();
	bool ReadCollectionDifDesc();

	bool ReadCollectionRef1st(bool dec_mode, bool ref_mode);
	bool ReadCollectionAug(bool dec_mode, bool ref_mode);

	bool GetCollectionRef1st(vector<CFastaSequence> &data);
	bool GetCollectionDif(vector<CFastaSequence> &data, int32 id_pos);


public:
	CGDC();
	~CGDC();

	bool StartCompress(string _archive_name, uchar _compress_mode);
	bool AddCollection(string file_name, vector<CFastaSequence> &data, bool is_ref = false);
	bool FinishCompress(uint32 &size_ref, uint32 &size_dif, uint32 &size_aug);

	bool ListContents(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents);

	bool StartDecompress(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents);
	bool GetCollection(uint32 col_id, string &file_name, vector<CFastaSequence> &data, bool &is_ref);
	bool ReleaseCollection(uint32 col_id, vector<CFastaSequence> &data);
	bool FinishDecompress();

	bool StartExtract(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents, bool _ref_mode);
	bool InfoCollection(uint32 seq_id, string &file_name, vector<CFastaSequence> &data, bool &is_ref);
	bool FinishExtract();
	bool Read(int col_id, int seq_id, int from, int to, unsigned char *&seq, int &len);

	bool SetMatchParams(int _min_match_1st_len, int _min_match_ext_len, int _min_match_total_len);
	bool SetAugParams(int _min_aug_len);
	bool SetHashStep(int _hash_step);
	bool SetHashColisions(int _hash_colisions);
	bool SetRefBlockSizeExp(int _block_size_exp);
	bool SetDifBlockSizeExp(int _block_size_exp);
	bool SetRefSeqNo(uint32 _ref_seq_no);

	bool SetVerboseLevel(int level);
};

#endif
