#include "stdafx.h"
/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#include "defs.h"
#include "bit_stream.h"
#include <algorithm>

using namespace std;

// ********************************************************************************************
CBitStream::CBitStream()
{
	file		     = NULL;

	io_buffer	     = NULL;
	io_buffer_size   = 0;
	io_buffer_pos    = 0;
	file_pos         = 0;
	word_buffer_pos  = 0;
	word_buffer		 = 0;
	word_buffer_size = 32;
	mode			 = mode_none;

	for(int32 i = 0; i < 32; ++i)
		n_bit_mask[i] = (1u << i) - 1;
}

// ********************************************************************************************
CBitStream::~CBitStream()
{
	delete[] io_buffer;

	if(file)
		fclose(file);
}

// ********************************************************************************************
bool CBitStream::Create(char *file_name)
{
	if(file)
		fclose(file);
	if((file = my_fopen(file_name, "wb")) != NULL)
		mode = mode_file_write;

	IO_BUFFER_SIZE   = 1 << 20;
	io_buffer	     = new unsigned char[IO_BUFFER_SIZE];
	io_buffer_size   = IO_BUFFER_SIZE;

	word_buffer_size = 32;
	file_pos = 0;

	return mode == mode_file_write;	
}

// ********************************************************************************************
bool CBitStream::Open(char *file_name)
{
	if(file)
		fclose(file);
	if((file = my_fopen(file_name, "rb")) != NULL)
		mode = mode_file_read;

	IO_BUFFER_SIZE   = 1 << 20;
	io_buffer	     = new unsigned char[IO_BUFFER_SIZE];
	io_buffer_size   = IO_BUFFER_SIZE;

	word_buffer_size = 8;
	io_buffer_pos    = IO_BUFFER_SIZE;
	file_pos         = 0;

	if(mode == mode_file_read)
	{
		my_fseek(file, 0, SEEK_END);
		file_size = my_ftell(file);
		my_fseek(file, 0, SEEK_SET);
	} 
	
	return mode == mode_file_read;
}

// ********************************************************************************************
bool CBitStream::OpenRA(char *file_name)
{
	if(file)
		fclose(file);
	if((file = my_fopen(file_name, "rb")) != NULL)
		mode = mode_file_read_ra;

	IO_BUFFER_SIZE   = 1 << 12;
	io_buffer	     = new unsigned char[IO_BUFFER_SIZE];
	io_buffer_size   = IO_BUFFER_SIZE;

	word_buffer_size = 8;
	io_buffer_pos    = IO_BUFFER_SIZE;
	file_pos         = 0;

	if(mode == mode_file_read_ra)
	{
		my_fseek(file, 0, SEEK_END);
		file_size = my_ftell(file);

		my_fseek(file, 0, SEEK_SET);
	} 
	
	return mode == mode_file_read_ra;
}

// ********************************************************************************************
bool CBitStream::Close()
{
	if(!file)
		return true;

	if(mode == mode_file_write)
	{
		if(word_buffer_pos)
			FlushPartialWordBuffer();
		WriteBuffer();
	}

	fclose(file);
	file = NULL;
	mode = mode_none;

	return true;
}

// ********************************************************************************************
bool CBitStream::SetPos(uint64 pos)
{
	if(mode != mode_file_read && mode != mode_file_read_ra)
		return false;

	if(pos >= file_pos - io_buffer_pos && pos < file_pos - io_buffer_pos + io_buffer_size)
		io_buffer_pos = (int32) (pos - (file_pos - io_buffer_pos));
	else
	{
		if(my_fseek(file, pos, SEEK_SET) == EOF)
			return false;
		io_buffer_pos = IO_BUFFER_SIZE;
		file_pos      = pos;
	}
	
	word_buffer_pos = 0;
	word_buffer     = 0;

	return true;
}
 