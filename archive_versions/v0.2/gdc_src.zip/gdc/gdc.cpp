/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <iterator>
#include <string>
#include <algorithm>
#include <bitset>
#include <numeric>
#include <time.h>
#include <ctype.h>
#include <vector>
#include <assert.h>

#include "compressor.h"
#include "fasta.h"

using namespace std;

enum t_working_mode {wm_compress, wm_decompress, wm_list} working_mode;

uint32 min_match_1st_len;
uint32 min_match_ext_len;
uint32 min_match_total_len;
uint32 min_aug_len;
uint32 hash_step;
uint32 hash_colisions;
int32 extr_col_no;
int32 ref_col_no;
int32 extr_from, extr_to;
uint32 dif_block_size_exp;
uint32 ref_block_size_exp;
uchar compress_mode;

vector<string> file_names;
string archive_name;

CGDC *gdc;

int headers_size;

bool random_access();

void show_usage();
bool parse_parameters(int argc, char *argv[]);
bool compress();
bool decompress();
bool list();
int find_ref_seq();

// ******************************************************************************
void show_usage()
{
	cout << "Genome Differential Compressor v. 0.2\n";
	cout << "Usage: gdc <mode> [options] <archive_name> file{[, file]}|@list_of_files\n";
	cout << "  mode - c (compress), d (decompress), l (list contnents)\n";
	cout << "  archive_name - name of the archive file\n";
	cout << "  file - list o files to compress (only in compress mode)\n";
	cout << "  list_of_files - file containing a list of file (1 file per line) to compress\n";
	cout << "  options:\n";
	cout << "    -bdX - block size exponent (block size will be 2^X)\n";
	cout << "      0 (no blocks) and [10,32]; (default: 0)\n"; 
	cout << "    -brX - ref. sequence block size exponent (default: 13)\n";
	cout << "    -hcX - max. number of colisions, 0-unlimited (default: 0)\n";
	cout << "    -hsX - hashing step (default: 1)\n";
	cout << "    -maX - length of literals added to augumented ref. sequence (default:32)\n";
	cout << "    -mpX,Y,Z - match parameters (default: 13,4,13):\n";
	cout << "      X - min. len. of 1st part of a match\n";
	cout << "      Y - min. len. of 2nd and next parts of a match\n";
	cout << "      Z - min. total match len\n";
	cout << "    -rnX - no. of ref. sequences; if not given a single ref. seq. is looked for\n";
	cout << "    -rmX - ref. sequence compression mode: 0: faster, 1: better (default)\n";
	cout << "Examples:\n";
	cout << "  gdc c para @para_files\n";
	cout << "  gdc c -mp14,4,20 cere cere1.fa cere2.fa\n";
	cout << "  gdc d para\n";
}

// ******************************************************************************
bool parse_parameters(CGDC *gdc, int argc, char *argv[])
{
	int32 i;

	if(argc < 3)
		return false;

	if(strcmp(argv[1], "c") == 0)
		working_mode = wm_compress;
	else if(strcmp(argv[1], "d") == 0)
		working_mode = wm_decompress;
	else if(strcmp(argv[1], "l") == 0)
		working_mode = wm_list;
	else
		return false;

	extr_col_no = -1;
	extr_from   = -1;
	extr_to		= -1;
	ref_col_no  = -1;

	min_match_1st_len = 13;

	compress_mode = 1;

	for(i = 2; i < argc && argv[i][0] == '-'; ++i)
	{
		if(strncmp(argv[i], "-mp", 3) == 0)
		{
			char *p1 = strchr(argv[i], ',');
			if(!p1)
				continue;
			char *p2 = strchr(p1+1, ',');
			if(!p2)
				continue;
			*p1 = *p2 = 0;
			gdc->SetMatchParams(atoi(&argv[i][3]), atoi(p1+1), atoi(p2+1));
			min_match_1st_len = atoi(&argv[i][3]);
		}
		else if(strncmp(argv[i], "-bd", 3) == 0)
			gdc->SetDifBlockSizeExp(atoi(&argv[i][3]));
		else if(strncmp(argv[i], "-br", 3) == 0)
			gdc->SetRefBlockSizeExp(atoi(&argv[i][3]));
		else if(strncmp(argv[i], "-ma", 3) == 0)
			gdc->SetAugParams(atoi(&argv[i][3]));
		else if(strncmp(argv[i], "-hs", 3) == 0)
			gdc->SetHashStep(atoi(&argv[i][3]));
		else if(strncmp(argv[i], "-hc", 3) == 0)
			gdc->SetHashColisions(atoi(&argv[i][3]));
		else if(strncmp(argv[i], "-rm", 3) == 0)
			compress_mode = argv[i][3] - '0';
		else if(strncmp(argv[i], "-rn", 3) == 0)
		{
			char *p1 = argv[i]+3;
			ref_col_no = atoi(p1);
			gdc->SetRefSeqNo(ref_col_no);
		}
		else if(strncmp(argv[i], "-es", 3) == 0)
			extr_col_no = atoi(&argv[i][3]);
		else if(strncmp(argv[i], "-er", 3) == 0)
		{
			char *p1 = strchr(argv[i], ',');
			if(!p1)
				continue;
			*p1 = 0;
			extr_from = atoi(&argv[i][3]);
			extr_to   = atoi(p1+1);
		}
	}

	// No archive name
	if(argc < i+1 || (working_mode == wm_compress && argc < i+2))
		return false;

	archive_name = string(argv[i]);
	if(argc == i+1)
		file_names.clear();
	else
	{
		if(argv[i+1][0] == '@')
		{
			FILE *f_names = fopen(argv[i+1]+1, "rt");
			if(!f_names)
			{
				cout << "No file: " << string(argv[i+1]+1) << "\n";
				return false;
			}
			file_names.clear();
			char name[1024];
			while(fscanf(f_names, "%s", name) != EOF)
				file_names.push_back(string(name));
			fclose(f_names);
		}
		else
			file_names.assign(argv+i+1, argv+argc);
	}

	return true;
}

// ******************************************************************************
bool random_access()
{
	return true;
}

// ******************************************************************************
bool compress()
{
	vector<CFastaSequence> data;
	CFastaFile *fasta = new CFastaFile();
	uint32 size_ref, size_dif, size_aug;

	if(ref_col_no <= 0)
	{
		int id = find_ref_seq();
		string name = file_names[id];
		file_names.erase(file_names.begin() + id);
		file_names.insert(file_names.begin(), name);
		ref_col_no = 1;
	}

	gdc->StartCompress(archive_name, compress_mode);
	for(int i = 0; i < file_names.size(); ++i)
	{
		if(!fasta->Open(file_names[i]))
		{
			cout << "File " << file_names[i] << " does not exists or is not in FASTA format\n";
			continue;
		}
		fasta->Read(data);
		gdc->AddCollection(file_names[i], data, i < ref_col_no);
		fasta->Close();
	}

	gdc->FinishCompress(size_ref, size_dif, size_aug);

	cout << "***********************************************\n";
	cout << "Total size: " << size_ref + size_dif + size_aug << " B is a sum of:\n";
	cout << "  ref. sequence  : ";
	cout.width(10);
	cout << size_ref << " B\n";
	cout << "  aug. sequence  : ";
	cout.width(10);
	cout << size_aug << " B\n";
	cout << "  other sequences: ";
	cout.width(10);
	cout << size_dif << " B\n";

	delete fasta;

	return true;
}

// ******************************************************************************
bool decompress()
{
	vector<CFastaSequence> data;
	CFastaFile *fasta = new CFastaFile();
	vector<CGDCSequenceDesc> contents;
	string file_name;
	bool is_ref;

	gdc->StartDecompress(archive_name, contents);

	for(int i = 0; i < contents.size(); ++i)
		if(file_names.empty() || find(file_names.begin(), file_names.end(), contents[i].file_name) != file_names.end())
		{
			gdc->GetCollection(i, file_name, data, is_ref);
			fasta->Create(file_name + ".ori");
			fasta->Write(data);
			fasta->Close();
			gdc->ReleaseCollection(i, data);
		}

	gdc->FinishDecompress();

	delete fasta;

	return true;
}

// ******************************************************************************
bool list()
{
	vector<CGDCSequenceDesc> contents;

	gdc->ListContents(archive_name, contents);

	cout << "Contents of the archive:\n";
	for(int i = 0; i < contents.size(); ++i)
	{
		cout << "Collection no. " << i << " (" << contents[i].file_name << "):\n";
		cout << "   " << contents[i].sizes.size() << " sequence(s)";
		cout << "  " << contents[i].start_poss.back() + contents[i].sizes.back() << "bp";
		if(contents[i].is_ref)
			cout << " - reference set";
		cout << "\n";
	}

	return true;
}

// ******************************************************************************
int find_ref_seq()
{
	clock_t t0;
	t0 = clock();

	vector<uint32> clear_data;

	cout << "--------------------------------\n";
	cout << "Looking for ref. sequence\n";

	for(int i = 0; i < file_names.size(); ++i)
	{
		cout << "\rTesting: " << file_names[i] << "  ";
		CFastaFile *fasta = new CFastaFile();
		if(!fasta->Open(file_names[i]))
			break;
		vector<CFastaSequence> seqs;
		fasta->Read(seqs);

		uint32 n_tot = 0;
		unsigned char *seq = fasta->raw_data;
		int seq_len = (int32) fasta->data_size;

		int32 num_N = 0;
		for(uint32 k = 0; k < min_match_1st_len; ++k)
			num_N += seq[k] == 'N';
		if(!num_N)
			n_tot++;
		for(int j = 0; j < seq_len - (int32) min_match_1st_len; ++j)
		{
			num_N -= seq[j] == 'N' || seq[j] == 'n';
			num_N += seq[j+min_match_1st_len] == 'N' || seq[j+min_match_1st_len] == 'n';

			if(!num_N)
				n_tot++;
		}

		clear_data.push_back(n_tot);

		fasta->Close();
	}

	vector<uint32>::iterator p = max_element(clear_data.begin(), clear_data.end());

	cout << "\rRef. sequence: " << file_names[p-clear_data.begin()] << "\n";
	cout << "Finding time: " << (double) (clock() - t0) / CLOCKS_PER_SEC << "s\n";

	return (int) (p - clear_data.begin());
}

// ******************************************************************************
int _tmain(int argc, _TCHAR* argv[])
{
/*#ifdef WIN32
	_CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif*/
	clock_t t0 = clock();

	gdc = new CGDC;

	if(!parse_parameters(gdc, argc, argv))
	{
		show_usage();
		delete gdc;
		return 0;
	}

	gdc->SetVerboseLevel(1);

	if(working_mode == wm_compress)
		compress();
	else if(working_mode == wm_decompress)
		decompress();
	else if(working_mode == wm_list)
		list();

	delete gdc;

	cout << "Total time: " << (double) (clock() - t0) / CLOCKS_PER_SEC << "s\n";

	return 0;
}

