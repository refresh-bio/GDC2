#include <stdio.h>
#include <ext/algorithm>
#include <iostream>
using namespace std;
using __gnu_cxx::copy_n;
