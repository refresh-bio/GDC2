/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _SEQUENCE_H
#define _SEQUENCE_H

#include "defs.h"
#include <vector>
#include "block.h"
#include "hasher.h"
#include "bit_memory.h"
#include "huffman.h"
#include "ref.h"
#include "utils.h"

using namespace std;

class CSequence 
{
	string col_name;

	uchar *seq;
	int32 seq_size;
	vector<CReference *> refs;
	CBitMemory seq_decomp;
	uchar *comp_seq;

	int extr_b_start, extr_b_end;
	int extr_from, extr_to;

	uint32 P_FLAG_MAX_EXP;
	uint32 P_LIT_MAX_EXP;
	uint32 P_LEN_MAX_EXP;
	uint32 P_FLAG_MAX;
	uint32 P_LIT_MAX;
	uint32 P_LEN_MAX;

	uint32 S_LENS;
	uint32 S_OFFSETS;

	vector<CBlock*> blocks;

	CHasher *hasher;
	vector<int32> block_starts;
	vector<int32> block_sizes;
	vector<int32> block_comp_starts;

	vector<int32> *stat_flags;
	vector<int32> *stat_literals;
	vector<vector<int32> > *stat_lens;
	vector<vector<int32> > *stat_offsets;

	CHuffman huf_flags;
	CHuffman huf_literals;
	vector<CHuffman> huf_lens;
	vector<CHuffman> huf_offsets;

	CPackedBuffer *pbf, *pbl;

	vector<int> stat_lit_len;
public:
	uchar *lit_coding;
	uchar *alph;
	uint32 sigma;

	int tot_best_tnd, tot_tnd, tot_periods, tot_lit;

	int32 NRunLen(int32 pos);
	void AddLiterals(int32 &literals_start, int32 cur_pos, uchar last_exc_char);

	inline void CopyFromRef(CBitMemory &bm, CReference *ref, int32 len, int32 &pos, int32 extr_from, int32 extr_to, 
		uint32 block_sft, uint32 block_msk);

public:
	int32 block_size_exp;
	int32 block_size;
	int32 min_match_1st_len;
	int32 min_match_ext_len;
	int32 min_match_total_len;
	int32 min_aug_len;
	static int32 OFF_COST_1;
	static int32 OFF_COST_2;
	static int32 OFF_COST_3;

	CSequence(string _col_name);
	~CSequence();

	bool SetSeq(uchar *_seq, int32 size);
	bool SetHasher(CHasher *_hasher);
	bool AddSeqRef(CReference *_ref);
	bool SetParams(int32 _min_match_1st_len, int32 _min_match_ext_len, int32 _min_match_total_len, int32 _min_aug_len, int32 _block_size_exp);

	bool Process();
	bool AdjustMaxs();
	bool PreCompress(uint32 _sigma, uchar *_alph, uchar *_lit_coding, 
		vector<int32> *_stat_flags, vector<int32> *_stat_literals, vector<vector<int32> > *_stat_lens, vector<vector<int32> > *_stat_offsets);
	bool Compress();
	bool Store(uchar *&buffer, int32 &size);

	bool Load(uchar *buffer, int32 size);
	bool InitBlocks(int32 b_from, int32 b_to);
	bool Decompress();
	bool DecompressRange(int from, int to);
	bool UnProcess();
	bool UnProcessRA(int32 extr_size);
	bool GetUnSequence(uchar *&_seq_decomp, uint32 &len_decomp);
	bool Release();
};

// ********************************************************************************************
inline void CSequence::CopyFromRef(CBitMemory &bm, CReference *ref, int32 len, int32 &pos, int32 extr_from, int32 extr_to, 
	uint32 block_sft, uint32 block_msk)
{
	if(pos + len <= extr_from)
	{
		pos += len;
		return;
	}
	if(pos < extr_from)
	{
		len -= extr_from - pos;
		pos = extr_from;
	}

	while(len)
	{
		int block_id  = pos >> block_sft;
		int block_pos = pos & block_msk;
		int	cur_len;

		if(pos + len > (int32) ((pos | block_msk) + 1))
		{
			cur_len  = (block_msk + 1) - block_pos;
			len     -= cur_len;
		}
		else
		{
			cur_len = len;
			len     = 0;
		}

		if(pos + cur_len > extr_to)
		{
			cur_len = extr_to - pos;
			len = 0;
		}

		bm.PutBytes(ref->blocks[block_id].seq_comp + block_pos, cur_len);
	}
}

#endif
