/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _BLOCK_H
#define _BLOCK_H

#include <vector>
#include "defs.h"
#include "bit_memory.h"
#include "huffman.h"
#include "utils.h"

using namespace std;

typedef uchar t_flag;

const int N_MISMATCHES = 29;
const int N_FLAGS      = N_MISMATCHES+3;
const int N_LIT        = N_MISMATCHES+2;

const int TAG_PSEUDO_MATCH_N = 255;
const int TAG_PSEUDO_MATCH_n = 254;
const int TAG_LARGE_MINUS 	 = 253;
const int TAG_LARGE_PLUS 	 = 252;
const int TAG_SEQ_AUG	 	 = 251;
const int MAX_NO_SEQ_REF     = 40;
const int TAG_SEQ_REF_SEL	 = TAG_SEQ_AUG - 2*MAX_NO_SEQ_REF;
const int TAG_RANGE_0		 = (TAG_SEQ_REF_SEL - 2) / 2;

const int LIT_MIN			 = 32;

const int LEN_THR			 = 128;

class CBlock
{
public:
	uchar *buffer;
	vector<t_flag> flags;
	vector<uchar> literals, exc_literals;
	vector<int32> lens;
	vector<pair<uchar, int32> > offsets;

	vector<uint16> packed_flags;
	vector<uint16> packed_literals;
	vector<uint16> packed_lens[2];
	vector<uchar> packed_offsets[5];

	vector<int32> *stat_flags;
	vector<int32> *stat_literals;
	vector<vector<int32> > *stat_lens;
	vector<vector<int32> > *stat_offsets;

	CHuffman *huf_flags;
	CHuffman *huf_literals;
	vector<CHuffman> *huf_lens;
	vector<CHuffman> *huf_offsets;
	
	CPackedBuffer *pbf, *pbl;

	uint32 flags_pos;
	uint32 literals_pos;
	uint32 lens_pos;
	uint32 offsets_pos;

	int32 min_match_len;
    int32 min_match_len_ext;

	uint32 P_FLAG_MAX;
	uint32 P_LIT_MAX;
	uint32 S_LENS;
	uint32 S_OFFSETS;
	uint32 ctx_lens[2];
	uint32 ctx_offsets[5];

	uchar *lit_coding;
	uchar *alph;
	uint32 sigma;

	char *col_name;
	uint32 seq_size;
	uint32 seq_pos;
	uint32 seq_start_block;
	uint32 block_size_exp;

public:
	CBitMemory *bit_memory;

public:
	CBlock(int32 _min_match_len = 13, int32 _min_match_len_ext = 4);
	CBlock(const CBlock &y); 
	~CBlock();

	void SetParams(int32 _min_match_len, int32 _min_match_len_ext, int32 _block_size_exp, CPackedBuffer *_pbf, CPackedBuffer *_pbl);
	void AdjustCtx();

	void Reset();
	inline void AddLiteral(uchar c, uchar last_exc_char);
	inline void AddLiterals(uchar *c, uint32 len, uchar last_exc_char);
	inline void AddMatch(uchar tag, int32 offset, vector<int32> &v_lens, vector<uchar> &v_chars, vector<uchar> &v_non_chars);
	inline void AddMatch(uchar tag, int32 offset, int32 len);
	void SetStatTables(vector<int32> *_stat_flags, vector<int32> *_stat_literals, vector<vector<int32> > *_stat_lens, 
		vector<vector<int32> > *_stat_offsets);
	void SetHuffmans(CHuffman *_huf_flags, CHuffman *_huf_literals, vector<CHuffman> *_huf_lens, vector<CHuffman> *_huf_offsets);

	void Open(uchar *buffer, uint32 len);
	void StartGetFlag();
	inline t_flag GetFlag();
	inline void GetLiteral(uchar &c);
	inline void GetLiterals(vector<uchar> &c);
	inline void GetMatch(uchar flag, uchar &tag, int32 &offset, vector<int32> &v_lens, vector<uchar> &v_chars);
	inline void GetMatch(uchar &tag, int32 &offset, int32 &len);
	inline void SkipLiteral();
	inline void SkipLiterals();
	void ProcessExclusions();

	void RLE0Pack(vector<uchar> &data, uchar s0, uchar s0a, uchar s0b);
	void RLE0UnPack(vector<uchar> &data, uint32 raw_size, uchar s0, uchar s0a, uchar s0b);
	void RLE0PackLen(vector<uchar> &data, int32 len, uchar s0a, uchar s0b);

	void PreCompress();
	void Compress();

	void Decompress();
	void Restart();
};


// ********************************************************************************************
inline void CBlock::AddLiteral(uchar c, uchar last_exc_char = ' ')
{
	flags.push_back(0);
	literals.push_back(c);
	exc_literals.push_back(last_exc_char);
}

// ********************************************************************************************
inline void CBlock::AddLiterals(uchar *c, uint32 len, uchar last_exc_char)
{
	flags.push_back(N_LIT);
	lens.push_back(len - LIT_MIN);
	
	literals.push_back(c[0]);
	exc_literals.push_back(last_exc_char);

	exc_literals.insert(exc_literals.end(), len-1, ' ');
	literals.insert(literals.end(), c+1, c+len);
}

// ********************************************************************************************
inline void CBlock::AddMatch(uchar tag, int32 offset, int32 len)
{
	flags.push_back(1);
	offsets.push_back(make_pair(tag, offset));
	lens.push_back(len-min_match_len);
}

// ********************************************************************************************
inline void CBlock::AddMatch(uchar tag, int32 offset, vector<int32> &v_lens, vector<uchar> &v_chars, vector<uchar> &v_non_chars)
{
	flags.push_back((t_flag) v_lens.size());
	offsets.push_back(make_pair(tag, offset));

	lens.push_back(v_lens[0]-min_match_len);
	for(int32 i = 1; i < v_lens.size(); ++i)
		lens.push_back(v_lens[i]-min_match_len_ext);

	literals.insert(literals.end(), v_chars.begin(), v_chars.end());
	exc_literals.insert(exc_literals.end(), v_non_chars.begin(), v_non_chars.end());
}

// ********************************************************************************************
inline t_flag CBlock::GetFlag()
{
	if(flags_pos >= flags.size())
		return N_FLAGS;

	return flags[flags_pos++];
}

// ********************************************************************************************
inline void CBlock::GetLiteral(uchar &c)
{
	c = literals[literals_pos++];
}

// ********************************************************************************************
inline void CBlock::GetLiterals(vector<uchar> &c)
{
	c.clear();
	uint32 len = lens[lens_pos++] + LIT_MIN;
	for(uint32 i = 0; i < len; ++i)
		c.push_back(literals[literals_pos++]);
}

// ********************************************************************************************
inline void CBlock::GetMatch(uchar &tag, int32 &offset, int32 &len)
{
	tag    = offsets[offsets_pos].first;
	offset = offsets[offsets_pos].second;
	offsets_pos++;
	len    = lens[lens_pos++]+min_match_len;
}

// ********************************************************************************************
inline void CBlock::GetMatch(uchar flag, uchar &tag, int32 &offset, vector<int32> &v_lens, vector<uchar> &v_chars)
{
	tag    = offsets[offsets_pos].first;
	offset = offsets[offsets_pos].second;

	offsets_pos++;
	v_lens.clear();
	v_chars.clear();
	v_lens.push_back(lens[lens_pos++]+min_match_len);

	v_lens.insert(v_lens.end(), &lens[lens_pos], &lens[lens_pos]+(flag-1));
	for(int32 i = 1; i < flag; ++i)
		v_lens[i] += min_match_len_ext;
	lens_pos += flag-1;
	v_chars.assign(&literals[literals_pos], &literals[literals_pos]+(flag-1));
	literals_pos += flag-1;
}

// ********************************************************************************************
inline void CBlock::SkipLiteral()
{
	literals_pos++;
}

// ********************************************************************************************
inline void CBlock::SkipLiterals()
{
	uint32 len = lens[lens_pos++] + min_match_len;
	literals_pos += len;
}

#endif
