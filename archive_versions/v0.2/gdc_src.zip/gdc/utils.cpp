#include "stdafx.h"
/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#include "utils.h"
#include <algorithm>
#include <numeric>
#include <assert.h>
#include <iostream>
#include <math.h>
#include "block.h"

using namespace std;


// ********************************************************************************************
uint32 int_log(uint32 x, uint32 base)
{
	uint32 r = 0;

	if(base == 0)
		return 1;
	if(base == 1)
		base++;

	for(uint32 tmp = base; tmp <= x; tmp *= base)
		++r;

	return r;
}

// ********************************************************************************************
void report(string text, uint64 pos, uint64 size, bool new_line)
{
	cout << "\r                                                                        ";
	cout.width(7);
	cout.precision(1);
	cout.setf(ios::fixed);
	cout << "\r" << text << " " << 100.0 * pos / size << "%";
	if(new_line)
		cout << "\n";
}

// ********************************************************************************************
void report(string text, bool new_line)
{
	cout << "\r                                                                        ";
	cout << "\r" << text;
	if(new_line)
		cout << "\n";
}

// ********************************************************************************************
CPackedBuffer::CPackedBuffer()
{
	raw_buf    = NULL;
	packed_buf = NULL;

	raw_pbuf    = NULL;
	packed_pbuf = NULL;

	n_raw    = 0;
	n_packed = 0;

	magic_nos = NULL;
}

// ********************************************************************************************
CPackedBuffer::~CPackedBuffer()
{
	if(magic_nos)
		delete[] magic_nos;
}

// ********************************************************************************************
void CPackedBuffer::SetBufs(uint32 _n_raw, uint32 _n_packed, vector<uchar> *_raw_buf, vector<uint16> *_packed_buf)
{
	raw_buf    = _raw_buf;
	packed_buf = _packed_buf;

	n_raw    = _n_raw;
	n_packed = _n_packed;

	raw_pbuf    = NULL;
	packed_pbuf = NULL;
}

// ********************************************************************************************
void CPackedBuffer::SetBufs(uint32 _n_raw, uint32 _n_packed, uchar *_raw_pbuf, uint16 *_packed_pbuf, uint32 _raw_pbuf_len, uint32 _packed_pbuf_len)
{
	raw_pbuf        = _raw_pbuf;
	packed_pbuf     = _packed_pbuf;
	raw_pbuf_len    = _raw_pbuf_len;
	packed_pbuf_len = _packed_pbuf_len;

	n_raw    = _n_raw;
	n_packed = _n_packed;

	raw_buf    = NULL;
	packed_buf = NULL;
}

// ********************************************************************************************
void CPackedBuffer::Init(uint32 _n_packed)
{
	n_packed = _n_packed;

	if(magic_nos)
		delete[] magic_nos;

	magic_nos = new t_magic_no[n_packed];

	uint64 two32 = ((uint64) 1) << 32;
	uint64 two31 = two32 >> 1;

	magic_nos[0].magic = 0;
	magic_nos[0].shift = 0;

	for(uint64 i = 1; i < (uint64) n_packed; ++i)
	{
		uint64 t = two31 + (i >> 31);
		uint64 anc = t - 1 - t % i;
		uint64 p = 31;
		uint64 q1 = two31 / anc;
		uint64 r1 = two31 - q1 * anc;
		uint64 q2 = two31 / i;
		uint64 r2 = two31 - q2 * i;
		uint64 delta;
		do {
			p = p + 1;
			q1 = 2 * q1;
			r1 = 2 * r1;
			if(r1 >= anc) {
				q1 = q1 + 1;
				r1 = r1 - anc;
			}
			q2 = 2 * q2;
			r2 = 2 * r2;
			if(r2 >= i) {
				q2 = q2 + 1;
				r2 = r2 - i;
			}
			delta = i - r2;
		} while (q1 < delta || (q1 == delta && r1 == 0));

		uint64 mag = q2 + 1;
		uint64 shift = p - 32;

		magic_nos[i].magic = mag;
		magic_nos[i].shift = shift;
	}
}

// ********************************************************************************************
bool CPackedBuffer::Encode()
{
	uint32 i;

	if(!raw_buf || !packed_buf)
		return false;

	packed_buf->clear();

	// number of raw symbols packed together
	uint32 pck = int_log(n_packed, n_raw);
	uint32 tmp = 0;

	for(i = 0; i < raw_buf->size(); ++i)
	{
		if(i % pck == 0 && i > 0)
		{
			packed_buf->push_back((uint16) tmp);
			tmp = 0;
		}
		tmp = tmp * n_raw + (*raw_buf)[i];
	}

	for(; i % pck != 0; ++i)
		tmp *= n_raw;

	packed_buf->push_back((uint16) tmp);

	return true;
}

// ********************************************************************************************
bool CPackedBuffer::Decode()
{
	uint32 i, j, k;
	if(!raw_buf || !packed_buf)
		return false;

	// number of raw symbols packed together
	uint32 pck = int_log(n_packed, n_raw);
	uint64 tmp, tmp2;
	uint64 divs[32];
	t_magic_no ms[32];
	
	divs[pck-1] = 1;
	for(int i = pck-2; i >= 0; --i)
		divs[i] = divs[i+1] * n_raw;

	uint64 d = 1;
	for(int i = pck-1; i >= 0; --i)
	{
		ms[i].magic = magic_nos[d].magic;
		ms[i].shift = magic_nos[d].shift+32;
		d *= n_raw;
	}

	raw_buf->clear();
	raw_buf->reserve(packed_buf->size() * pck);
	uint32 max_i = (uint32) (packed_buf->size() * pck);
	for(i = k = 0, j = pck; i < max_i; ++i, ++j)
	{
		if(j == pck)
		{
			tmp = (*packed_buf)[k++];
			j = 0;
		}

		tmp2 = (tmp * ms[j].magic) >> ms[j].shift;
		raw_buf->push_back((uint32) tmp2);
		tmp -= tmp2 * divs[j];
	}

	return true;
}

// ********************************************************************************************
bool CPackedBuffer::EncodeP(uchar *coding)
{
	uint32 i;

	if(!raw_pbuf || !packed_pbuf)
		return false;

	uint32 packed_pbuf_pos = 0;

	// number of raw symbols packed together
	uint32 pck = int_log(n_packed, n_raw);
	uint16 tmp = 0;

	for(i = 0; i < raw_pbuf_len; ++i)
	{
		if(i % pck == 0 && i > 0)
		{
			packed_pbuf[packed_pbuf_pos++] = tmp;
			tmp = 0;
		}
		tmp = tmp * n_raw + coding[raw_pbuf[i]];
	}
	for(; i % pck != 0; ++i)
		tmp *= n_raw;

	packed_pbuf[packed_pbuf_pos++] = tmp;

	return true;
}

// ********************************************************************************************
bool CPackedBuffer::DecodeP(uchar *alph)
{
	uint32 i, j, k;
	if(!raw_pbuf || !packed_pbuf)
		return false;

	// number of raw symbols packed together
	uint32 pck = int_log(n_packed, n_raw);
	uint64 tmp, tmp2;
	uint64 divs[32];
	t_magic_no ms[32];
	
	divs[pck-1] = 1;
	for(int i = pck-2; i >= 0; --i)
		divs[i] = divs[i+1] * n_raw;

	uint64 d = 1;
	for(int i = pck-1; i >= 0; --i)
	{
		ms[i].magic = magic_nos[d].magic;
		ms[i].shift = magic_nos[d].shift+32;
		d *= n_raw;
	}

	uint32 raw_pbuf_pos = 0;
	uint32 max_i = packed_pbuf_len * pck;
	for(i = k = 0, j = pck; i < max_i && raw_pbuf_pos < raw_pbuf_len; ++i, ++j)
	{
		if(j == pck)
		{
			tmp = packed_pbuf[k++];
			j = 0;
		}

		tmp2 = (tmp * ms[j].magic) >> ms[j].shift;
		raw_pbuf[raw_pbuf_pos++] = alph[tmp2];
		tmp -= tmp2 * divs[j];
	}

	return true;
}
