/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz
  
  Version: 0.2
  Date   : 2011-May-16
*/

#ifndef _HUFFMAN_H
#define _HUFFMAN_H

#include "defs.h"
#include "bit_memory.h"

class CHuffman {
	int32 size;

	typedef struct tag_frequency {
		uint32 symbol;
		uint32 frequency;

		bool operator<(const struct tag_frequency &x) {
			return frequency > x.frequency || (frequency == x.frequency && symbol > x.symbol);
		}
	} t_frequency;

public:
	typedef struct {
		uint32 code;
		uint32 len;
	} t_code;

private:
public:			
	typedef struct {
		int32 left_child;
		int32 right_child;
	} t_node;

	t_frequency *heap;
	t_node *tree;
	int32 root_id;
	int32 n_symbols;
	int32 cur_id;
	int32 tmp_id;
	uint32 min_len;

	CBitMemory *bit_memory;
	uint32 bits_per_id;

	int32 *speedup_tree;

	void EncodeProcess(int32 node_id);
	int32 DecodeProcess(int32 node_id);
	void ComputeSpeedupTree();

public:
	t_code *codes;

	CHuffman(uint32 _size = 0);
	~CHuffman();

	bool Restart(uint32 _size = 0);
	inline bool Insert(const uint32 frequency);
	t_code* Complete(bool compact = true);
	inline int32 Decode(const uint32 bit);
	inline int32 DecodeFast(const uint32 bits);

	bool StoreTree(uchar *&mem, uint32 &len);
	bool LoadTree(uchar *mem, uint32 len);
};

// ********************************************************************************************
bool CHuffman::Insert(const uint32 frequency)
{
	if(n_symbols == size)
		return false;

	heap[n_symbols].symbol    = n_symbols;
	heap[n_symbols].frequency = frequency;
	n_symbols++;

	return true;
}

// ********************************************************************************************
int32 CHuffman::Decode(const uint32 bit) 
{
	if(cur_id < n_symbols)
		cur_id = root_id;
	if(bit)
		cur_id = tree[cur_id].right_child;
	else
		cur_id = tree[cur_id].left_child;
	if(cur_id < n_symbols)
		return cur_id;				// Symbol found
	else
		return -1;					// Not found yet
}

// ********************************************************************************************
inline int32 CHuffman::DecodeFast(const uint32 bits)
{
	cur_id = speedup_tree[bits];
	if(cur_id < n_symbols)
		return cur_id;				// Symbol found
	else
		return -1;					// Not found yet
}

#endif
