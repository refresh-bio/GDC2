#include "stdafx.h"
/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  
  Version: 0.2
  Date   : 2011-May-04
*/

#include <stdio.h>
#include <time.h>
#include <algorithm>

#include "compressor.h"

const char *FILE_MAGIC_NUMBER = "GDC\x02";

// ********************************************************************
CGDC::CGDC()
{
	f_dif = NULL;
	f_ref = NULL;
	f_aug = NULL;
	
	hasher = NULL;

	min_match_1st_len	= 13;
	min_match_ext_len	= 4;
	min_match_total_len = 13;
	min_aug_len			= 32;
	hash_step			= 1;
	hash_colisions		= 1 << 30;
	ref_seq_no			= 1;
	extr_seq_id			= -1;
	extr_from			= -1;
	extr_to				= -1;
	dif_block_size_exp	= 30;
	ref_block_size_exp  = 13;

	verbose_level       = 0;

	pbf = new CPackedBuffer();
	pbl = new CPackedBuffer();

	mode = gdc_none;
}

// ********************************************************************
CGDC::~CGDC()
{
	int i;

	if(hasher)
		delete hasher;

	ClearBufDifSeq();

	for(i = 0; i < Refs.size(); ++i)
	{
		if(!Refs[i].ref || Refs[i].seq_ref != Refs[i].ref->raw_seq_ref)
			delete[] Refs[i].seq_ref;
		delete Refs[i].ref;
		delete[] Refs[i].comp_seq_ref;
	}

	delete pbf;
	delete pbl;
}

// ********************************************************************
bool CGDC::SetMatchParams(int _min_match_1st_len, int _min_match_ext_len, int _min_match_total_len)
{
	if(_min_match_1st_len <= 0 || _min_match_ext_len < 0 || _min_match_total_len <= 0)
		return false;

	min_match_1st_len   = _min_match_1st_len;
	min_match_ext_len   = _min_match_ext_len;
	min_match_total_len = _min_match_total_len;

	return true;
}

// ********************************************************************
bool CGDC::SetAugParams(int _min_aug_len)
{
	if(_min_aug_len <= 0)
		return false;

	min_aug_len = _min_aug_len;

	return true;
}

// ********************************************************************
bool CGDC::SetHashStep(int _hash_step)
{
	if(_hash_step < 1)
		return false;

	hash_step = _hash_step;

	return true;
}

// ********************************************************************
bool CGDC::SetHashColisions(int _hash_colisions)
{
	if(_hash_colisions < 0)
		return false;

	if(_hash_colisions == 0)
		hash_colisions = 1 << 30;
	else
		hash_colisions = _hash_colisions;

	return true;
}

// ********************************************************************
bool CGDC::SetRefBlockSizeExp(int _block_size_exp)
{
	if(_block_size_exp < 0 || _block_size_exp > 31)
		return false;

	ref_block_size_exp = _block_size_exp;

	return true;
}

// ********************************************************************
bool CGDC::SetDifBlockSizeExp(int _block_size_exp)
{
	if(_block_size_exp < 0 || _block_size_exp > 31)
		return false;

	dif_block_size_exp = _block_size_exp;

	return true;
}

// ********************************************************************
bool CGDC::SetRefSeqNo(uint32 _ref_seq_no)
{
	ref_seq_no = _ref_seq_no;

	return true;
}

// ********************************************************************
bool CGDC::SetNames()
{
	if(archive_name == "")
		return false;

	archive_names[0] = archive_name + ".gdc1";
	archive_names[1] = archive_name + ".gdc2";
	archive_names[2] = archive_name + ".gdc3";

	return true;
}

// ********************************************************************
bool CGDC::SetVerboseLevel(int level)
{
	if(level < 0 || level > 1)
		return false;

	verbose_level = level;

	return true;
}

// ******************************************************************************
char *CGDC::PrepSeqName(char *seq_name, char *seq_name_pref, int id = 0)
{
	strcpy(seq_name, seq_name_pref);
	
	char tmp[10];
	sprintf(tmp, "%d", id);
	strcat(seq_name, tmp);

	return seq_name;
}

// ******************************************************************************
void CGDC::ClearBufDifSeq()
{
	for(int i = 0; i < buf_dif_seq.size(); ++i)
		if(buf_dif_seq[i].second)
		{
			CSequence *seq = buf_dif_seq[i].second;
			delete seq;

		}
	buf_dif_seq.clear();
}

// ********************************************************************
bool CGDC::Read(int col_id, int seq_id, int from, int to, unsigned char *&seq, int &len)
{
	if(col_id < 0 || col_id >= archive_contents.size() || from < 0 || from > to || seq_id < 0 || seq_id >= archive_contents[col_id].seq_names.size())
		return false;

	extr_col_id = col_id;
	extr_seq_id = seq_id;
	extr_from   = archive_contents[col_id].start_poss[seq_id] + from + 1;
	extr_to     = archive_contents[col_id].start_poss[seq_id] + to + 1;

	len = (int32) (extr_to - extr_from + 1);
	seq = new uchar[len+1];

	// to correctly decompress when the first symbol is encoded with literal exclusions
	if(extr_from > 0)
		extr_from--;

	if(col_id == 0)
	{
		int32 pos = 0;

		uint32 block_sft = Refs[1].ref->block_size_exp;
		uint32 block_msk = (1 << block_sft) - 1;

		CReference *cur_ref = Refs[1].ref;

		if(cur_ref->compress_mode == 1)
		{
			cur_ref->StartRead();
			cur_ref->DecompressRange((uint32) extr_from, (uint32) extr_to);

			for(int64 k = extr_from+1; k < extr_from+1+len; ++k)
				seq[pos++] = cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk];
		}
		else
		{
			cur_ref->StartGetSymbol((uint32) extr_from);

			for(int64 k = extr_from+1; k < extr_from+1+len; ++k)
				seq[pos++] = cur_ref->GetSymbol();
		}

		seq[len] = 0;

		return true;
	}

	// Differential sequences
	CSequence *sequence = buf_dif_seq[extr_col_id].second;

	uchar *seq_decomp;
	uint32 len_decomp;

	sequence->DecompressRange(extr_from, extr_to);
	sequence->UnProcessRA((uint32) (extr_to-extr_from));
	sequence->GetUnSequence(seq_decomp, len_decomp);

	if(extr_from > 0)
		copy_n(seq_decomp+2, len, seq);
	else
		copy_n(seq_decomp+1, len, seq);
	seq[len] = 0;

	sequence->Release();
	
	return true;
}

// ********************************************************************
bool CGDC::StartCompress(string _archive_name, uchar _compress_mode)
{
	if(mode != gdc_none)
		return false;

	archive_name = _archive_name;
	SetNames();

	mode = gdc_compress;
	compress_mode = _compress_mode;
	archive_contents.clear();

	// 0th positions are for aug. sequence
	Refs.clear();

	Refs.push_back(CRefCollection());

	total_size = 0;
	_size_ref  = 0;
	_size_aug  = 0;
	_size_dif  = 0;
	dif_seq_pos.clear();

	f_ref = fopen(archive_names[0].c_str(), "wb");
	f_dif = fopen(archive_names[1].c_str(), "wb");
	f_aug = fopen(archive_names[2].c_str(), "wb");

	return true;
}

// ********************************************************************
bool CGDC::AddCollection(string file_name, vector<CFastaSequence> &data, bool is_ref)
{
	if(mode != gdc_compress)
		return false;

	// First sequence must be a reference
	if(archive_contents.empty())
		is_ref = true;

	archive_contents.push_back(CGDCSequenceDesc(file_name, data, (uint32) archive_contents.size(), is_ref));

	if(archive_contents.size() == 1)
		AddCollectionRef1st(file_name, data);
	else
	{
		AddCollectionDif(file_name, data);
		if(is_ref)
			AddCollectionRefAux(file_name, data);
	}
	
	return true;
}

// ********************************************************************
bool CGDC::AddCollectionRef1st(string &col_name, vector<CFastaSequence> &data)
{
	uchar *seq_ref_comp;
	uint32 seq_ref_comp_size;

	Refs.push_back(CRefCollection());
	vector<uint32> s_pos;
	uint32 pos = 0;

	// Copy main ref. seq. data
	uint32 tot_len = 0;
	for(int i = 0; i < data.size(); ++i)
		tot_len += data[i].size;

	hasher = new CHasher();

	Refs[1].seq_ref = new uchar[tot_len+hash_step+(uint32)4];
	copy_n(data[0].raw_data, tot_len, Refs[1].seq_ref+1);
	Refs[1].seq_ref[tot_len+1] = '\0';
	fill_n(Refs[1].seq_ref+tot_len+2, hash_step+2, '~');

	Refs[1].ref = new CReference();
	Refs[1].ref->SetRefSeq(Refs[1].seq_ref+1, tot_len);
	Refs[1].ref->SetBlockSize(ref_block_size_exp);
	Refs[1].seq_ref_size = tot_len;
	cout << "\r" << col_name << " compressing...";

	Refs[1].ref->Compress(compress_mode, col_name, seq_ref_comp, seq_ref_comp_size);
	_size_ref = seq_ref_comp_size;

	hasher->SetParams(hash_step, hash_colisions, min_match_1st_len, min_match_ext_len);
	hasher->SetRefSeq(Refs[1].seq_ref, Refs[1].seq_ref_size);

	// Data
	fwrite(FILE_MAGIC_NUMBER, 1, 4, f_ref);
	fwrite(seq_ref_comp, 1, seq_ref_comp_size, f_ref);
	delete[] seq_ref_comp;

	// Compression parameters
	CBitMemory bm;
	bm.Create(1024);

	bm.PutWord(min_match_1st_len);
	bm.PutWord(min_match_ext_len);
	bm.PutWord(min_match_total_len);
	bm.PutWord(min_aug_len);
	bm.PutWord((uint32) s_pos.size());
	for(int i = 0; i < s_pos.size(); ++i)
		bm.PutWord(s_pos[i]);

	// Store archive description
	bm.PutBytes((uchar *) archive_contents[0].file_name.c_str(), (uint32) archive_contents[0].file_name.length()+1);
	bm.PutWord(archive_contents[0].id);
	bm.PutByte((uchar) archive_contents[0].is_ref);
	bm.PutByte((uchar) archive_contents[0].eol_type);
	bm.PutWord((uint32) archive_contents[0].sizes.size());

	for(int i = 0; i < archive_contents[0].sizes.size(); ++i)
	{
		bm.PutBytes((uchar*) archive_contents[0].seq_names[i].c_str(), (uint32) archive_contents[0].seq_names[i].length()+1);
		bm.PutWord(archive_contents[0].sizes[i]);
		bm.PutWord(archive_contents[0].line_lens[i]);
	}

	fwrite(bm.mem_buffer, 1, bm.mem_buffer_pos, f_ref);
	uint32 tmp = (uint32) bm.mem_buffer_pos;
	fwrite(&tmp, sizeof(uint32), 1, f_ref);
	total_size += (uint32) bm.mem_buffer_pos + sizeof(uint32) + 4;

	_size_ref += (uint32) bm.mem_buffer_pos + sizeof(uint32) + 4;

	cout << "\r" << col_name << " compressed: ";
	cout.width(10);
	cout << _size_ref << " B  (ref. collection)\n";

	return true;
}

// ********************************************************************
bool CGDC::AddCollectionRefAux(string &col_name, vector<CFastaSequence> &data)
{
	Refs.push_back(CRefCollection());
	vector<uint32> s_pos;
	uint32 pos = 0;

	// Copy main ref. seq. data
	uint32 tot_len = 0;
	for(int i = 0; i < data.size(); ++i)
		tot_len += data[i].size;

	Refs.back().seq_ref = new uchar[tot_len+hash_step+(uint32)4];
	copy_n(data[0].raw_data, tot_len, Refs.back().seq_ref+1);
	Refs.back().seq_ref[tot_len+1] = '\0';
	fill_n(Refs.back().seq_ref+tot_len+2, hash_step+2, '~');

	Refs.back().seq_ref_size = tot_len;
	if(verbose_level > 0)
		cout << "\rAdditional ref. sequence hashing...";

	hasher->SetRefSeq(Refs.back().seq_ref, Refs.back().seq_ref_size);

	return true;
}

// ********************************************************************
bool CGDC::AddCollectionDif(string &col_name, vector<CFastaSequence> &data)
{
	// Prepare data structures for statistics
	vector<int32> stat_flags;
	vector<int32> stat_literals;
	vector<vector<int32> > stat_lens(2);
	vector<vector<int32> > stat_offsets(5);

	for(uint32 i = 0; i < 2; ++i)
	{
		stat_lens[i].resize(256);
		fill(stat_lens[i].begin(), stat_lens[i].end(), 0);
	}

	for(uint32 i = 0; i < 5; ++i)
	{
		stat_offsets[i].resize(256);
		fill(stat_offsets[i].begin(), stat_offsets[i].end(), 0);
	}

	dif_seq_pos.push_back((uint32) _size_dif);

	CSequence *sequence;
	uchar *seq_alt;

	FindAlphabet(data);

	uint32 tot_len = 0;
	for(int i = 0; i < data.size(); ++i)
		tot_len += data[i].size;
		
	seq_alt = new uchar[tot_len+14];
	copy_n(data[0].raw_data, tot_len, seq_alt+1);
	seq_alt[tot_len+2] = '\0';
	fill_n(seq_alt+tot_len+3, 10, 1);

	if(verbose_level > 0)
		report(col_name + ": compressing...", 0, 1, false);

	sequence = new CSequence(col_name, pbf, pbl);
	sequence->SetParams(min_match_1st_len, min_match_ext_len, min_match_total_len, min_aug_len, dif_block_size_exp);
	sequence->SetHasher(hasher);
	sequence->SetSeq(seq_alt, tot_len);
	sequence->Process();
	sequence->AdjustMaxs();
	sequence->PreCompress(sigma, alph, lit_coding, &stat_flags, &stat_literals, &stat_lens, &stat_offsets);

	sequence->Compress();

	uchar *seq_comp;
	uint32 len_comp;
	sequence->Store(seq_comp, len_comp);
	_size_dif += (uint32) len_comp;
	if(verbose_level > 0)
	{
		cout << "\r" << col_name << " compressed: ";
		cout.width(10);
		cout << len_comp << " B     (total: ";
		cout.width(10);
		cout << _size_dif << " B)\n";
	}
	total_size += (uint32) len_comp;

	fwrite(seq_comp, 1, len_comp, f_dif);

	delete sequence;
	delete[] seq_alt;
	delete[] seq_comp;

	return true;
}

// ********************************************************************************************
void CGDC::FindAlphabet(vector<CFastaSequence> &data)
{
	uint32 i;

	multimap<uint32, uchar, greater<uint32> > tmm;

	for(i = 0; i < 256; ++i)
		if(data[0].char_stat[i])
			tmm.insert(make_pair(data[0].char_stat[i], i));

	sigma = 0;
	fill_n(lit_coding, 256, 255);
	for(multimap<uint32, uchar, greater<uint32> >::iterator p = tmm.begin(); p != tmm.end(); ++p)
	{
		lit_coding[p->second] = sigma;
		alph[sigma] = p->second;
		sigma++;
	}
}

// ********************************************************************
bool CGDC::FinishCompress(uint32 &size_ref, uint32 &size_dif, uint32 &size_aug)
{
	if(mode != gdc_compress)
		return false;

	int32 i, j;
	CBitMemory bm;
	bm.Create(1024);

	// Store differential sequences
	dif_seq_pos.push_back((uint32) _size_dif);
	bm.PutWord((uint32) dif_seq_pos.size());
	for(i = 0; i < dif_seq_pos.size(); ++i)
		bm.PutWord(dif_seq_pos[i]);
	bm.PutByte((uchar) dif_block_size_exp);

	// Store archive description
	bm.PutWord((uint32) archive_contents.size());
	for(j = 1; j < archive_contents.size(); ++j)
	{
		bm.PutBytes((uchar *) archive_contents[j].file_name.c_str(), (uint32) archive_contents[j].file_name.length()+1);
		bm.PutWord(archive_contents[j].id);
		bm.PutByte((uchar) archive_contents[j].is_ref);
		bm.PutByte((uchar) archive_contents[j].eol_type);
		bm.PutWord((uint32) archive_contents[j].sizes.size());

		for(int i = 0; i < archive_contents[j].sizes.size(); ++i)
		{
			bm.PutBytes((uchar*) archive_contents[j].seq_names[i].c_str(), (uint32) archive_contents[j].seq_names[i].length()+1);
			bm.PutWord(archive_contents[j].sizes[i]);
			bm.PutWord(archive_contents[j].line_lens[i]);
		}
	}

	fwrite(bm.mem_buffer, 1, bm.mem_buffer_pos, f_dif);
	uint32 tmp = (uint32) bm.mem_buffer_pos;
	fwrite(&tmp, sizeof(uint32), 1, f_dif);
	total_size += bm.mem_buffer_pos + sizeof(bm.mem_buffer_pos);

	_size_dif += (uint32) bm.mem_buffer_pos + sizeof(uint32);

	// Store aug. ref. sequence
	uchar *seq_ref_comp;
	uint32 seq_ref_comp_size;

	Refs[0].ref = new CReference();
	Refs[0].ref->SetRefSeq(hasher->seqs_ref[0]+1, (int32) hasher->seqs_size[0]-1);
	Refs[0].ref->SetBlockSize(ref_block_size_exp);
	Refs[0].ref->Compress(compress_mode, "aug. seq.", seq_ref_comp, seq_ref_comp_size);
	if(seq_ref_comp_size)
	{
		fwrite(seq_ref_comp, 1, seq_ref_comp_size, f_aug);
		delete[] seq_ref_comp;
	}

	_size_aug = seq_ref_comp_size;

	fclose(f_ref);
	fclose(f_dif);
	fclose(f_aug);
	
	mode = gdc_none;

	size_ref = _size_ref;
	size_aug = _size_aug;
	size_dif = _size_dif;

	return true;
}

// ********************************************************************
bool CGDC::StartDecompress(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents)
{
	if(mode != gdc_none)
		return false;

	archive_name = _archive_name;
	SetNames();
	archive_contents.clear();

	if(!(f_ref = fopen(archive_names[0].c_str(), "rb")))
		return false;
	if(!(f_dif = fopen(archive_names[1].c_str(), "rb")))
	{
		fclose(f_ref);
		return false;
	}
	if(!(f_aug = fopen(archive_names[2].c_str(), "rb")))
	{
		fclose(f_ref);
		fclose(f_dif);
		return false;
	}

	mode = gdc_decompress;

	ReadCollectionRef1stDesc();
	ReadCollectionAugDesc();
	ReadCollectionDifDesc();

	Refs.clear();
	Refs.push_back(CRefCollection());
	Refs.push_back(CRefCollection());

	_archive_contents = archive_contents;

	// Decompress ref. sequences
	for(int i = 0; i < archive_contents.size(); ++i)
	{
		string file_name;
		vector<CFastaSequence> data;
		bool tmp;

		if(archive_contents[i].is_ref)
		{
			GetCollection(i, file_name, data, tmp);

			refs_data.push_back(data);
			if(i > 0)
			{
				Refs.push_back(CRefCollection());
				Refs.back().seq_ref		 = data[0].raw_data;
				Refs.back().seq_ref_size = data.back().start_pos + data.back().size;
				Refs.back().ref = new CReference;
				Refs.back().ref->SetRefSeq(Refs.back().seq_ref, Refs.back().seq_ref_size);
			}
		}
	}

	return true;
}

// ********************************************************************
bool CGDC::ListContents(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents)
{
	if(mode != gdc_none)
		return false;

	archive_name = _archive_name;
	SetNames();
	archive_contents.clear();

	if(!(f_ref = fopen(archive_names[0].c_str(), "rb")))
		return false;
	if(!(f_dif = fopen(archive_names[1].c_str(), "rb")))
	{
		fclose(f_ref);
		return false;
	}
	if(!(f_aug = fopen(archive_names[2].c_str(), "rb")))
	{
		fclose(f_ref);
		fclose(f_dif);
		return false;
	}

	ReadCollectionRef1stDesc();
	ReadCollectionAugDesc();
	ReadCollectionDifDesc();

	fclose(f_ref);
	fclose(f_dif);
	fclose(f_aug);
	f_ref = NULL;
	f_dif = NULL;
	f_aug = NULL;	

	_archive_contents = archive_contents;

	return true;
}

// ********************************************************************
bool CGDC::StartExtract(string _archive_name, vector<CGDCSequenceDesc> &_archive_contents, bool _ref_mode)
{
	if(mode != gdc_none)
		return false;

	archive_name = _archive_name;
	SetNames();
	archive_contents.clear();

	if(!(f_ref = fopen(archive_names[0].c_str(), "rb")))
		return false;
	if(!(f_dif = fopen(archive_names[1].c_str(), "rb")))
	{
		fclose(f_ref);
		return false;
	}
	if(!(f_aug = fopen(archive_names[2].c_str(), "rb")))
	{
		fclose(f_ref);
		fclose(f_dif);
		return false;
	}

	mode = gdc_extract;
	ref_mode = _ref_mode;

	ReadCollectionRef1stDesc();
	ReadCollectionAugDesc();
	ReadCollectionDifDesc();

	_archive_contents = archive_contents;
	Refs.clear();
	Refs.push_back(CRefCollection());
	Refs.push_back(CRefCollection());

	ReadCollectionRef1st(false, ref_mode != 0);
	ReadCollectionAug(false, ref_mode != 0);

	buf_dif_seq.clear();
	buf_dif_seq.resize(1);

	uint32 no_ref = 1;

	for(uint32 i = 1; i < archive_contents.size(); ++i)
	{
		if(archive_contents[i].is_ref)
			no_ref++;
	}

	if(no_ref > 1)
		return FinishExtract();

	for(uint32 i = 1; i < archive_contents.size(); ++i)
	{
		buf_dif_seq.push_back(make_pair(make_pair(dif_seq_pos[i-1], dif_seq_pos[i]-dif_seq_pos[i-1]), (CSequence*) NULL));

		my_fseek(f_dif, buf_dif_seq[i].first.first, SEEK_SET);
		uint32 data_size = buf_dif_seq[i].first.second;
		uchar *data = new uchar[data_size];
		fread(data, 1, data_size, f_dif);
		
		CSequence *sequence = new CSequence(archive_contents[i].file_name, pbf, pbl);
		buf_dif_seq[i].second = sequence;
		sequence->SetParams(min_match_1st_len, min_match_ext_len, min_match_total_len, min_aug_len, dif_block_size_exp);
		sequence->AddSeqRef(Refs[0].ref);
		sequence->AddSeqRef(Refs[1].ref);
		sequence->lit_coding = lit_coding;
		sequence->alph       = alph;
		sequence->Load(data, data_size);
	}

	
	return true;
}

// ********************************************************************
bool CGDC::ReadCollectionRef1stDesc()
{
	int32 header_size;
	char magic_number[4];

	fread(magic_number, 1, 4, f_ref);
	if(memcmp(magic_number, FILE_MAGIC_NUMBER, 4))
		return 0;

	my_fseek(f_ref, -(int32) sizeof(int32), SEEK_END);
	fread(&header_size, sizeof(int32), 1, f_ref);

	my_fseek(f_ref, -(int32) (header_size + sizeof(int32)), SEEK_END);
	ref1st_seq_size = (uint32) my_ftell(f_ref) - 4;
	uchar *buffer = new uchar[header_size];
	fread(buffer, 1, header_size, f_ref);
	my_fseek(f_ref, 4, SEEK_SET);
	CBitMemory bm;
	bm.Open(buffer, header_size);

	uint32 tmp, len;

	bm.GetWord(min_match_1st_len);
	bm.GetWord(min_match_ext_len);
	bm.GetWord(min_match_total_len);
	bm.GetWord(min_aug_len);
	bm.GetWord(tmp);

	vector<uint32> s_pos(tmp);
	for(int i = 0; i < s_pos.size(); ++i)
	{
		bm.GetWord(tmp);
		s_pos[i] = tmp;
	}
	
	// Read archive description
	archive_contents.clear();
	archive_contents.push_back(CGDCSequenceDesc());
	len = (uint32) strlen((char *) bm.mem_buffer+bm.mem_buffer_pos);
	archive_contents[0].file_name = string((char *) bm.mem_buffer+bm.mem_buffer_pos);
	bm.SkipBytes(len+1);
	bm.GetWord(archive_contents[0].id);
	bm.GetBool(archive_contents[0].is_ref);
	bm.GetByte(tmp);
	archive_contents[0].eol_type = (uchar) tmp;
	bm.GetWord(tmp);
	
	archive_contents[0].sizes.resize(tmp);
	archive_contents[0].seq_names.resize(tmp);
	archive_contents[0].line_lens.resize(tmp);
	archive_contents[0].start_poss.resize(tmp);

	for(int i = 0; i < archive_contents[0].sizes.size(); ++i)
	{
		len = (uint32) strlen((char *) bm.mem_buffer+bm.mem_buffer_pos);
		archive_contents[0].seq_names[i] = string((char *) bm.mem_buffer+bm.mem_buffer_pos);
		bm.SkipBytes(len+1);
		bm.GetWord(archive_contents[0].sizes[i]);
		bm.GetWord(archive_contents[0].line_lens[i]);
		if(i == 0)
			archive_contents[0].start_poss[0] = 0;
		else
			archive_contents[0].start_poss[i] = archive_contents[0].start_poss[i-1] + archive_contents[0].sizes[i-1];
	}
	
	delete[] buffer;

	return true;
}

// ********************************************************************
bool CGDC::ReadCollectionAugDesc()
{
	my_fseek(f_aug, 0, SEEK_END);
	aug_seq_size = (uint32) my_ftell(f_aug);
	my_fseek(f_aug, 0, SEEK_SET);

	return true;
}

// ********************************************************************
bool CGDC::ReadCollectionDifDesc()
{
	uint32 header_size;
	uint32 tmp;
	int32 i, j, len;

	my_fseek(f_dif, -(int32) sizeof(int32), SEEK_END);
	fread(&header_size, sizeof(int32), 1, f_dif);

	my_fseek(f_dif, -(int32) (header_size + sizeof(int32)), SEEK_END);
	uchar *buffer = new uchar[header_size];
	fread(buffer, 1, header_size, f_dif);
	my_fseek(f_dif, 0, SEEK_SET);
	CBitMemory bm;
	bm.Open(buffer, header_size);
	
	// Read differential sequences description
	bm.GetWord(tmp);
	dif_seq_pos.resize(tmp);
	for(i = 0; i < dif_seq_pos.size(); ++i)
		bm.GetWord(dif_seq_pos[i]);
	bm.GetByte(dif_block_size_exp);

	// Read archive description
	bm.GetWord(tmp);
	archive_contents.resize(tmp);
	for(j = 1; j < archive_contents.size(); ++j)
	{
		len = (int32) strlen((char*) bm.mem_buffer+bm.mem_buffer_pos);
		archive_contents[j].file_name = string((char*) bm.mem_buffer+bm.mem_buffer_pos);
		bm.SkipBytes(len+1);
		bm.GetWord(archive_contents[j].id);
		bm.GetBool(archive_contents[j].is_ref);
		bm.GetByte(tmp);
		archive_contents[j].eol_type = (uchar) tmp;
		bm.GetWord(tmp);
		archive_contents[j].seq_names.resize(tmp);
		archive_contents[j].sizes.resize(tmp);
		archive_contents[j].line_lens.resize(tmp);
		archive_contents[j].start_poss.resize(tmp);

		for(int i = 0; i < archive_contents[j].sizes.size(); ++i)
		{
			len = (int32) strlen((char*) bm.mem_buffer+bm.mem_buffer_pos);
			archive_contents[j].seq_names[i] = string((char*) bm.mem_buffer+bm.mem_buffer_pos);
			bm.SkipBytes(len+1);
			bm.GetWord(archive_contents[j].sizes[i]);
			bm.GetWord(archive_contents[j].line_lens[i]);
			if(i == 0)
				archive_contents[j].start_poss[0] = 0;
			else
				archive_contents[j].start_poss[i] = archive_contents[j].start_poss[i-1] + archive_contents[j].sizes[i-1];
		}
	}

	delete[] buffer;

	return true;
}

// ********************************************************************
bool CGDC::ReadCollectionRef1st(bool dec_mode, bool ref_mode)
{
	if(Refs[1].ref)
		return false;

	Refs[1].ref = new CReference;
	Refs[1].comp_seq_ref = new uchar[ref1st_seq_size];
	Refs[1].in  = NULL;

	fread(Refs[1].comp_seq_ref, 1, ref1st_seq_size, f_ref);
	Refs[1].ref->SetCompRefSeq(Refs[1].comp_seq_ref, ref1st_seq_size);

	if(dec_mode)
		Refs[1].ref->Decompress(Refs[1].ref->file_name, Refs[1].seq_ref, Refs[1].seq_ref_size);
	else
		Refs[1].ref->PrepareDecompress(ref_mode);
	
	return true;
}

// ********************************************************************
bool CGDC::ReadCollectionAug(bool dec_mode, bool ref_mode)
{
	if(Refs[0].ref)
		return false;

	if(aug_seq_size)
	{
		Refs[0].ref = new CReference;
		Refs[0].comp_seq_ref = new uchar[aug_seq_size];
		Refs[0].in  = NULL;

		fread(Refs[0].comp_seq_ref, 1, aug_seq_size, f_aug);
		Refs[0].ref->SetCompRefSeq(Refs[0].comp_seq_ref, aug_seq_size);

		if(dec_mode)
			Refs[0].ref->Decompress(Refs[0].ref->file_name, Refs[0].seq_ref, Refs[0].seq_ref_size);
		else
			Refs[0].ref->PrepareDecompress(ref_mode);
	}
		
	return true;
}

// ********************************************************************
bool CGDC::GetCollection(uint32 col_id, string &file_name, vector<CFastaSequence> &data, bool &is_ref)
{
	int32 i;

	if(mode != gdc_decompress)
		return false;
	if(archive_contents[0].id == col_id)
	{
		is_ref = true;
		file_name = archive_contents[0].file_name;

		return GetCollectionRef1st(data);
	}
	for(i = 1; i < archive_contents.size(); ++i)
	{
		if(archive_contents[i].id == col_id)
			break;
	}
	if(i == archive_contents.size())
		return false;

	file_name = archive_contents[i].file_name;
	is_ref    = archive_contents[i].is_ref;

	return GetCollectionDif(data, i);
}

// ********************************************************************
bool CGDC::ReleaseCollection(uint32 col_id, vector<CFastaSequence> &data)
{
	if(!data.empty() && col_id >= refs_data.size())
	{
		delete[] data[0].raw_data;
		data.clear();
	}

	return true;
}

// ********************************************************************
bool CGDC::GetCollectionRef1st(vector<CFastaSequence> &data)
{
	if(!Refs[1].ref)
	{
		if(verbose_level > 0)
			cout << archive_contents[0].file_name << ": decompressing ...";
		bool r = ReadCollectionRef1st(true, true);

		if(verbose_level > 0)
			cout << "\r" << archive_contents[0].file_name << ": decompressed     \n";
		if(!r)
			return false;
	}
	if(!Refs[0].ref)
		if(!ReadCollectionAug(true, true))
			return false;

	if(refs_data.size() > 0)
	{
		data = refs_data[0];
		return true;
	}

	data.resize(archive_contents[0].sizes.size());
	for(int32 i = 0; i < archive_contents[0].sizes.size(); ++i)
	{
		data[i].line_len = archive_contents[0].line_lens[i];
		data[i].raw_data = Refs[1].seq_ref; 
		data[i].eol_type = archive_contents[0].eol_type;
		data[i].seq_name = archive_contents[0].seq_names[i];
		data[i].size     = archive_contents[0].sizes[i];
		if(i == 0)
			data[i].start_pos = 1;
		else
			data[i].start_pos = data[i-1].start_pos + data[i-1].size;
	}

	return true;
}

// ********************************************************************
bool CGDC::GetCollectionDif(vector<CFastaSequence> &data, int32 id_pos)
{
	data.resize(archive_contents[id_pos].sizes.size());

	if(refs_data.size() > id_pos)
	{
		data = refs_data[id_pos];
		return true;
	}

	uchar *raw_data;
	uint32 raw_size;

	if(verbose_level > 0)
		cout << archive_contents[id_pos].file_name << ": decompressing ...";
		
	CSequence *sequence = new CSequence(archive_contents[id_pos].file_name, pbf, pbl);
	for(int i = 0; i < Refs.size(); ++i)
		sequence->AddSeqRef(Refs[i].ref);

	uint32 comp_len = dif_seq_pos[id_pos] - dif_seq_pos[id_pos-1];
	uchar *comp_data = new uchar[comp_len];
	my_fseek(f_dif, dif_seq_pos[id_pos-1], SEEK_SET);
	fread(comp_data, 1, comp_len, f_dif);

	sequence->SetParams(min_match_1st_len, min_match_ext_len, min_match_total_len, min_aug_len, dif_block_size_exp);
	sequence->lit_coding = lit_coding;
	sequence->alph       = alph;
	sequence->Load(comp_data, comp_len);
	sequence->InitBlocks(-1, -1);
	sequence->Decompress();
	sequence->UnProcess();
	sequence->GetUnSequence(raw_data, raw_size);

//	uchar *raw_data_copy = new uchar[raw_size+1];
//	copy_n(raw_data, raw_size+1, raw_data_copy);
	for(int32 i = 0; i < archive_contents[id_pos].sizes.size(); ++i)
	{
		data[i].line_len = archive_contents[id_pos].line_lens[i];
//		data[i].raw_data = raw_data_copy;
		data[i].raw_data = raw_data;
		data[i].seq_name = archive_contents[id_pos].seq_names[i];
		data[i].size     = archive_contents[id_pos].sizes[i];
		data[i].eol_type = archive_contents[id_pos].eol_type;
		if(i == 0)
			data[i].start_pos = 1;
		else
			data[i].start_pos = data[i-1].start_pos + data[i-1].size;
	}

//	delete[] comp_data;
	delete sequence;

	if(verbose_level > 0)
		cout << "\r" << archive_contents[id_pos].file_name << ": decompressed        \n";

	return true;
}

// ********************************************************************
bool CGDC::FinishDecompress()
{
	if(mode != gdc_decompress)
		return false;

	mode = gdc_none;

	fclose(f_ref);
	fclose(f_dif);
	fclose(f_aug);

	return true;
}

// ********************************************************************
bool CGDC::InfoCollection(uint32 seq_id, string &file_name, vector<CFastaSequence> &data, bool &is_ref)
{
	int32 i;

	if(mode != gdc_extract)
		return false;
	if(archive_contents[0].id == seq_id)
	{
		is_ref = true;
		file_name = archive_contents[0].file_name;

		return GetCollectionRef1st(data);
	}
	for(i = 1; i < archive_contents.size(); ++i)
	{
		if(archive_contents[i].id == seq_id)
			break;
	}
	if(i == archive_contents.size())
		return false;

	file_name = archive_contents[i].file_name;
	is_ref    = archive_contents[i].is_ref;

	return GetCollectionDif(data, i);
}

// ********************************************************************
bool CGDC::FinishExtract()
{
	if(mode != gdc_extract)
		return false;

	ClearBufDifSeq();

	mode = gdc_none;

	return true;
}
