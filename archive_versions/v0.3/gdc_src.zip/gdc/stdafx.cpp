#include "stdafx.h"

/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Author: Sebastian Deorowicz
  
  Version: 0.3
  Date   : 2011-Aug-05
*/
