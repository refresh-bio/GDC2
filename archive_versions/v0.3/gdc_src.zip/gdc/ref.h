/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Author: Sebastian Deorowicz
  
  Version: 0.3
  Date   : 2011-Aug-05
*/

#ifndef _REF_H
#define _REF_H
#include "defs.h"
#include "huffman.h"
#include "block.h"
#include "bit_memory.h"
#include <vector>
#include <utility>
#include <string>

using namespace std;

const int P_MAX_REF_LIT = 1 << 12;

class CRefBlock
{
public:
	uchar *seq_comp;
	bool is_compressed;
	int32 block_start;

public:
	CRefBlock();
	~CRefBlock();
};

class CReference
{
public:
	int64 in_pos;
	string file_name;

	uchar *raw_seq_ref;
	uint32 seq_ref_size;
	bool release_ref;

	uchar *raw_comp_seq_ref;
	uint32 comp_seq_ref_size;

	uint16 *raw_seq_pck;
	bool raw_seq_pck_alloc;
	uint32 seq_pck_size;

	uchar *raw_seq_comp;
	uint32 seq_comp_size;
	uint32 ra_seq_pos;

	uint32 block_size_exp;
	uint32 block_size;
	uint32 block_size_mask;
	uint32 n_blocks;
	uchar compress_mode;
	vector<int64> block_starts;

	static uint32 MEMORY_POOL_MAX_SIZE;
	vector<pair<uchar *, int32> > memory_pool;
	uint32 mp_pos;
	vector<CRefBlock> blocks;
	uint16 *memory_tmp;
	bool ref_mode;

	CPackedBuffer *pb;

	uchar coding[256];
	int32 sigma;
	int32 stats[P_MAX_REF_LIT];
	uchar alph[256];
	uint32 pck;

	uchar **lut;
	uchar *raw_lut;

	CHuffman *huf;
	CBitMemory *bit_memory;

	uint32 b_id;
	uint16 *block_pck;
	uint32 b_pos;
	uint32 b_pos_p;
	uint32 b_pos_c;

	void FindAlphabet();
	bool DecompressBlock(uint32 block_id);
	bool DecompressBlockPart(uint32 block_id, uint32 from, uint32 to);
	void PrepareLUT();

public:
	CReference();
	CReference(const CReference &y); 
	~CReference();

	bool SetRefSeq(uchar *_raw_seq_ref, uint32 _size);
	bool SetCompRefSeq(uchar *_raw_comp_seq_ref, uint32 _size);
	void SetBlockSize(uint32 _block_size_exp);
	bool Compress(uchar _compress_mode, string col_name, uchar *&seq_comp, uint32 &size);
	bool Decompress(string col_name, uchar *&seq_comp, uint32 &size);

	bool PrepareDecompress(bool ref_mode);
	void StartRead();
	bool DecompressRange(uint32 extr_from, uint32 extr_to);

	inline void StartGetSymbol(uint32 extr_from);
	inline uchar GetSymbol();
	inline void SkipSymbols(uint32 n);
};

// ********************************************************************
inline void CReference::StartGetSymbol(uint32 extr_from)
{
	b_id      = (extr_from-1) >> block_size_exp;
	block_pck = raw_seq_pck + block_starts[b_id] - 1;
	b_pos     = (extr_from-1) & block_size_mask;
	b_pos_p   = b_pos / pck;
	b_pos_c   = b_pos - b_pos_p * pck;
}

// ********************************************************************
inline uchar CReference::GetSymbol()
{
	uchar r = lut[block_pck[b_pos_p]][b_pos_c];

	if(++b_pos > block_size_mask)
	{
		b_id++;
		block_pck = raw_seq_pck + block_starts[b_id] - 1;
		b_pos = 0;
		b_pos_p = 0;
		b_pos_c = 0;
	}
	else
	{
		if(++b_pos_c >= pck)
		{
			b_pos_c = 0;
			b_pos_p++;
		}
	}

	return r;
}

// ********************************************************************
inline void CReference::SkipSymbols(uint32 n)
{
	b_pos += n;

	int32 t = b_pos / block_size_mask;
	b_id += t;
	b_pos -= t * block_size_mask;
	block_pck = raw_seq_pck + block_starts[b_id] - 1;
	b_pos_p   = b_pos / pck;
	b_pos_c   = b_pos - b_pos_p * pck;
}

#endif
