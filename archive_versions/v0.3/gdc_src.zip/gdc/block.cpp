#include "stdafx.h"
/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  
  Version: 0.2
  Date   : 2011-May-04
*/

#include "block.h"
#include "sequence.h"
#include <algorithm>
#include <assert.h>
#include <map>

using namespace std;

// ********************************************************************************************
CBlock::CBlock(int32 _min_match_len, int32 _min_match_len_ext) : min_match_len(_min_match_len), min_match_len_ext(_min_match_len_ext)
{
	buffer = NULL;
	bit_memory = NULL;
	block_size_exp = 30;

	pbf = NULL;
	pbl = NULL;
}

// ********************************************************************************************
// Moving constructor!
CBlock::CBlock(const CBlock &y)
{
	CBlock &x = const_cast<CBlock &>(y);

	buffer = x.buffer;
	x.buffer = NULL;

	flags.swap(x.flags);
	literals.swap(x.literals);
	exc_literals.swap(x.exc_literals);
	lens.swap(x.lens);
	offsets.swap(x.offsets);

	min_match_len = x.min_match_len;
	min_match_len_ext = x.min_match_len_ext;
	block_size_exp = x.block_size_exp;

	bit_memory = x.bit_memory;
	x.bit_memory = NULL;
	col_name = x.col_name;

	seq_size = x.seq_size;
	seq_pos  = x.seq_pos;
	seq_start_block = x.seq_start_block;

	pbf = x.pbf;
	pbl = x.pbl;
}

// ********************************************************************************************
CBlock::~CBlock()
{
	if(buffer)
		delete[] buffer;
	if(bit_memory)
		delete bit_memory;
}

// ********************************************************************************************
void CBlock::AdjustCtx()
{
	switch(S_LENS)
	{
	case 1:
		ctx_lens[0] = ctx_lens[1] = 0;
		break;
	case 2:
		ctx_lens[0] = 0; ctx_lens[1] = 1;
		break;
	}

	switch(S_OFFSETS)
	{
	case 2:
		ctx_offsets[0] = 0;	ctx_offsets[1] = 1; ctx_offsets[2] = 1; ctx_offsets[3] = 1; ctx_offsets[4] = 1; 
		break;
	case 3:
		ctx_offsets[0] = 0;	ctx_offsets[1] = 1; ctx_offsets[2] = 1; ctx_offsets[3] = 2; ctx_offsets[4] = 2; 
		break;
	case 4:
		ctx_offsets[0] = 0;	ctx_offsets[1] = 1; ctx_offsets[2] = 1; ctx_offsets[3] = 2; ctx_offsets[4] = 3; 
		break;
	case 5:
		ctx_offsets[0] = 0;	ctx_offsets[1] = 1; ctx_offsets[2] = 2; ctx_offsets[3] = 3; ctx_offsets[4] = 4; 
		break;
	}
}

// ********************************************************************************************
void CBlock::SetParams(int32 _min_match_len, int32 _min_match_len_ext, int32 _block_size_exp, CPackedBuffer *_pbf, CPackedBuffer *_pbl)
{
	min_match_len	  = _min_match_len;
	min_match_len_ext = _min_match_len_ext;
	block_size_exp    = _block_size_exp;

	pbf = _pbf;
	pbl = _pbl;
}

// ********************************************************************************************
void CBlock::Reset()
{
	flags.clear();
	literals.clear();
	exc_literals.clear();
	lens.clear();
	offsets.clear();
}

// ********************************************************************************************
void CBlock::Open(uchar *buffer, uint32 len)
{
	if(bit_memory)
		delete bit_memory;
	bit_memory = new CBitMemory();
	bit_memory->Open(buffer, len);
}

// ********************************************************************************************
void CBlock::SetStatTables(vector<int32> *_stat_flags, vector<int32> *_stat_literals, vector<vector<int32> > *_stat_lens, 
		vector<vector<int32> > *_stat_offsets)
{
	stat_flags    = _stat_flags;
	stat_literals = _stat_literals;
	stat_lens     = _stat_lens;
	stat_offsets  = _stat_offsets;
}

// ********************************************************************************************
void CBlock::SetHuffmans(CHuffman *_huf_flags, CHuffman *_huf_literals, vector<CHuffman> *_huf_lens, vector<CHuffman> *_huf_offsets)
{
	huf_flags    = _huf_flags;
	huf_literals = _huf_literals;
	huf_lens     = _huf_lens;
	huf_offsets  = _huf_offsets;
}

// ********************************************************************************************
void CBlock::ProcessExclusions()
{
	// Perform exclusions
	for(uint32 i = 0; i < literals.size(); ++i)
	{
		if(exc_literals[i] == ' ' || exc_literals[i] == '*' || exc_literals[i] == '$')
			continue;
		if(lit_coding[literals[i]] > lit_coding[exc_literals[i]])
			literals[i] = alph[lit_coding[literals[i]]-1];
	}
}

// ********************************************************************************************
void CBlock::PreCompress()
{
	// Compress flags
	packed_flags.clear();
	uchar p = 0;
	uint32 i;

	if(flags.size())
	{
		pbf->SetBufs(N_FLAGS, P_FLAG_MAX, &flags, &packed_flags);
		pbf->Encode();
	}

	// Compress literals
	packed_literals.clear();
	p = 0;

	ProcessExclusions();

	if(literals.size())
	{
		int aa = literals.back();
		for(i = 0; i < literals.size(); ++i)
			literals[i] = lit_coding[literals[i]];
		pbl->SetBufs(sigma, P_LIT_MAX, &literals, &packed_literals);
		pbl->Encode();
	}

	// Compress lens
	packed_lens[0].clear();
	packed_lens[1].clear();

	AdjustCtx();
	int tab_len[33] = {0};

	for(i = 0; i < lens.size(); ++i)
	{
		int32 ttt = lens[i];
			int j;
			for(j = 0; j < 33; ++j)
				if(ttt < (1 << j))
					break;
			tab_len[j]++;

		if(lens[i] < LEN_THR)
			packed_lens[0].push_back((uint32)lens[i]);
		else if(lens[i] < (256-LEN_THR-1)*256 + LEN_THR)
		{
			uint32 t = lens[i] - LEN_THR;
			packed_lens[0].push_back(LEN_THR+t/256);
			packed_lens[1].push_back(t % 256);
		}
		else
		{
			packed_lens[0].push_back(255);
			uint32 t = lens[i] - ((256-LEN_THR-1)*256 + LEN_THR);
			packed_lens[1].push_back(t >> 24);
			packed_lens[1].push_back((t >> 16) & 0xFF);
			packed_lens[1].push_back((t >> 8) & 0xFF);
			packed_lens[1].push_back(t & 0xFF);
		}
	}
	
	// Compress offsets
	for(i = 0; i < 5; ++i)
		packed_offsets[i].clear();

	int64 prev_off = 0;
	for(i = 0; i < offsets.size(); ++i)
	{
		if(offsets[i].first == TAG_PSEUDO_MATCH_N)
		{
			packed_offsets[0].push_back(TAG_PSEUDO_MATCH_N);
		}
		else if(offsets[i].first == TAG_PSEUDO_MATCH_n)
		{
			packed_offsets[0].push_back(TAG_PSEUDO_MATCH_n);
		}
		else if(offsets[i].first == TAG_SEQ_AUG)
		{
			packed_offsets[0].push_back(TAG_SEQ_AUG);
			uint64 t = offsets[i].second;
			packed_offsets[1].push_back((uint32) (t >> 24));
			packed_offsets[2].push_back((uint32) ((t >> 16) & 0xff));
			packed_offsets[3].push_back((uint32) ((t >> 8) & 0xff));
			packed_offsets[4].push_back((uint32) (t & 0xff));
		}
		else 
		{
			int64 off_to_write = offsets[i].second - prev_off;
			prev_off = offsets[i].second;
			uchar off_flag = offsets[i].first;

			if(ABS(off_to_write) < (int64) TAG_RANGE_0 && off_flag == 0)		// current collection and small value
			{
				packed_offsets[0].push_back((uchar) (off_to_write+TAG_RANGE_0));
			}
			else
			{
				if(off_flag == 0)
				{
					if(off_to_write > 0)
						packed_offsets[0].push_back(TAG_LARGE_PLUS);
					else
						packed_offsets[0].push_back(TAG_LARGE_MINUS);
				}
				else
				{
					if(off_to_write > 0)
						packed_offsets[0].push_back(TAG_SEQ_REF_SEL+(off_flag-TAG_SEQ_REF_SEL)*2-1);
					else
						packed_offsets[0].push_back(TAG_SEQ_REF_SEL+(off_flag-TAG_SEQ_REF_SEL)*2-2);
				}
				uint64 t = (uint64) ABS(off_to_write);
				packed_offsets[1].push_back((uchar) (t >> 24));
				packed_offsets[2].push_back((uchar) ((t >> 16) & 0xff));
				packed_offsets[3].push_back((uchar) ((t >> 8) & 0xff));
				packed_offsets[4].push_back((uchar) (t & 0xff));
			}
		}
	}
	
	RLE0Pack(packed_offsets[0], TAG_RANGE_0, TAG_RANGE_0, 0);

	// Compute stats
	for(i = 0; i < packed_flags.size(); ++i)
		(*stat_flags)[packed_flags[i]]++;
	for(i = 0; i < packed_literals.size(); ++i)
		(*stat_literals)[packed_literals[i]]++;
	for(i = 0; i < 2; ++i)
		for(uint32 j = 0; j < packed_lens[i].size(); ++j)
			(*stat_lens)[ctx_lens[i]][packed_lens[i][j]]++;

	for(i = 0; i < 5; ++i)
		for(uint32 j = 0; j < packed_offsets[i].size(); ++j)
			(*stat_offsets)[ctx_offsets[i]][packed_offsets[i][j]]++;
}

// ********************************************************************************************
void CBlock::Compress()
{
	uint32 i, j;

	if(bit_memory)
		delete bit_memory;
	bit_memory = new CBitMemory();

	CHuffman::t_code* codes;

	uint32 max_size = 0;
	max_size = max(max_size, (uint32) flags.size());
	max_size = max(max_size, (uint32) packed_flags.size());
	max_size = max(max_size, (uint32) literals.size());
	max_size = max(max_size, (uint32) packed_literals.size());
	max_size = max(max_size, (uint32) packed_offsets[0].size());
	uint32 n_bits = int_log(max_size, 2) + 1;

	bit_memory->PutBits(n_bits, 5);

	bit_memory->PutBits((uint32) flags.size(), n_bits);
	codes = huf_flags->codes;
	for(i = 0; i < packed_flags.size(); ++i)
		bit_memory->PutBits(codes[packed_flags[i]].code, codes[packed_flags[i]].len);

	int32 p = (int32) bit_memory->mem_buffer_pos;
	bit_memory->PutBits((uint32) (packed_literals.size()), n_bits);
	bit_memory->PutBits((uint32) (literals.size()), n_bits);
	codes = huf_literals->codes;
	for(i = 0; i < packed_literals.size(); ++i)
		bit_memory->PutBits(codes[packed_literals[i]].code, codes[packed_literals[i]].len);

	for(i = 0; i < 2; ++i)
	{
		codes = (*huf_lens)[ctx_lens[i]].codes;
		for(j = 0; j < packed_lens[i].size(); ++j)
			bit_memory->PutBits(codes[packed_lens[i][j]].code, codes[packed_lens[i][j]].len);
	}

	bit_memory->PutBits((uint32) (packed_offsets[0].size()), n_bits);
	for(i = 0; i < 5; ++i)
	{
		codes = (*huf_offsets)[ctx_offsets[i]].codes;
		for(j = 0; j < packed_offsets[i].size(); ++j)
			bit_memory->PutBits(codes[packed_offsets[i][j]].code, codes[packed_offsets[i][j]].len);
	}
	bit_memory->FlushPartialWordBuffer();
}

// ********************************************************************************************
void CBlock::Decompress()
{
	uint32 i, j;

	uint32 flags_size, packed_flags_size;
	CPackedBuffer pb;

	packed_flags.clear();
	packed_literals.clear();
	for(i = 0; i < 2; ++i)
		packed_lens[i].clear();
	for(i = 0; i < 5; ++i)
		packed_offsets[i].clear();
	flags.clear();
	literals.clear();
	lens.clear();
	offsets.clear();

	AdjustCtx();

	bit_memory->mem_buffer_pos = 0;

	uint32 n_bits;
	bit_memory->GetBits(n_bits, 5);

	// Decode flags
	bit_memory->GetBits(flags_size, n_bits);
	uint32 pck = int_log(P_FLAG_MAX, N_FLAGS);
	packed_flags_size = (flags_size + pck-1) / pck;

	packed_flags.reserve(packed_flags_size);
	for(i = 0; i < packed_flags_size; ++i)
	{
		uint32 bits;
		int32 h_tmp = -1;

		bit_memory->GetBits(bits, huf_flags->min_len);
		h_tmp = huf_flags->DecodeFast(bits);

		while(h_tmp < 0)
		{
			bit_memory->GetBit(bits);
			h_tmp = huf_flags->Decode(bits);
		}
		packed_flags.push_back(h_tmp);
	}

	uint32 stat_flag[N_FLAGS] = {0};
	flags.reserve(flags_size);
	pbf->SetBufs(N_FLAGS, P_FLAG_MAX, &flags, &packed_flags);
	pbf->Decode();
	for(i = 0; i < flags_size; ++i)
		stat_flag[flags[i]]++;
	flags.resize(flags_size);

	// Decode Literals
	pck = int_log(P_LIT_MAX, sigma);
	uint32 packed_literals_size;
	uint32 literals_size;
	bit_memory->GetBits(packed_literals_size, n_bits);
	bit_memory->GetBits(literals_size, n_bits);
	packed_literals.reserve(packed_literals_size);
	for(i = 0; i < packed_literals_size; ++i)
	{
		uint32 bits;
		int32 h_tmp = -1;

		bit_memory->GetBits(bits, huf_literals->min_len);
		h_tmp = huf_literals->DecodeFast(bits);

		while(h_tmp < 0)
		{
			bit_memory->GetBit(bits);
			h_tmp = huf_literals->Decode(bits);
		}
		packed_literals.push_back(h_tmp);
	}

	pbl->SetBufs(sigma, P_LIT_MAX, &literals, &packed_literals);
	pbl->Decode();
	literals.resize(literals_size);
	for(i = 0; i < literals_size; ++i)
		literals[i] = alph[literals[i]];

	// Decode lens
	uint32 packed_lens0_size = 0;
	for(i = 1; i < N_MISMATCHES+2; ++i)
		packed_lens0_size += stat_flag[i] * i;
	if(N_MISMATCHES+2 < N_FLAGS)
		packed_lens0_size += stat_flag[N_FLAGS-1];

	packed_lens[0].reserve(packed_lens0_size);
	for(i = 0; i < packed_lens0_size; ++i)
	{
		uint32 bits;
		int32 h_tmp = -1;

		bit_memory->GetBits(bits, (*huf_lens)[ctx_lens[0]].min_len);
		h_tmp = (*huf_lens)[ctx_lens[0]].DecodeFast(bits);

		while(h_tmp < 0)
		{
			bit_memory->GetBit(bits);
			h_tmp = (*huf_lens)[ctx_lens[0]].Decode(bits);
		}
		packed_lens[0].push_back(h_tmp);
	}

	for(i = 0; i < packed_lens0_size; ++i)
	{
		if(packed_lens[0][i] < LEN_THR)
		{
			lens.push_back(packed_lens[0][i]);
			continue;
		}
		if(packed_lens[0][i] < 255)
		{
			uint32 bits;
			int32 h_tmp = -1;

			bit_memory->GetBits(bits, (*huf_lens)[ctx_lens[1]].min_len);
			h_tmp = (*huf_lens)[ctx_lens[1]].DecodeFast(bits);
			
			while(h_tmp < 0)
			{
				bit_memory->GetBit(bits);
				h_tmp = (*huf_lens)[ctx_lens[1]].Decode(bits);
			}
			packed_lens[1].push_back(h_tmp);
			lens.push_back((packed_lens[0][i]-LEN_THR)*256 + h_tmp + LEN_THR);
		}
		else
		{		
			uint32 t = 0;
			uint32 bits;
			int32 h_tmp2;
			for(int32 j = 0; j < 4; ++j)
			{
				h_tmp2 = -1;

				bit_memory->GetBits(bits, (*huf_lens)[ctx_lens[1]].min_len);
				h_tmp2 = (*huf_lens)[ctx_lens[1]].DecodeFast(bits);

				while(h_tmp2 < 0)
				{
					bit_memory->GetBit(bits);
					h_tmp2 = (*huf_lens)[ctx_lens[1]].Decode(bits);
				}
				packed_lens[1].push_back(h_tmp2);
				t = (t << 8) + (uint32) h_tmp2;
			}
			t += (256-LEN_THR-1)*256 + LEN_THR;
			lens.push_back(t);
		}
	}

	// Decode offsets
	uint32 packed_offsets0_size = 0;
	uint32 raw_packed_offsets0_size = 0;
	for(i = 1; i < N_MISMATCHES+2; ++i)
		raw_packed_offsets0_size += stat_flag[i];
	bit_memory->GetBits(packed_offsets0_size, n_bits);

	packed_offsets[0].reserve(packed_offsets0_size);
	for(i = 0; i < packed_offsets0_size; ++i)
	{
		uint32 bits;
		int32 h_tmp = -1;

		bit_memory->GetBits(bits, (*huf_offsets)[ctx_offsets[0]].min_len);
		h_tmp = (*huf_offsets)[ctx_offsets[0]].DecodeFast(bits);

		while(h_tmp < 0)
		{
			bit_memory->GetBit(bits);
			h_tmp = (*huf_offsets)[ctx_offsets[0]].Decode(bits);
		}
		packed_offsets[0].push_back(h_tmp);
	}

	for(i = 1; i < 5; ++i)
		for(j = 0; j < packed_offsets0_size; ++j)
		{
			if(packed_offsets[0][j] < TAG_SEQ_REF_SEL || packed_offsets[0][j] >= TAG_PSEUDO_MATCH_n)
				continue;
			uint32 bits;
			int32 h_tmp = -1;

			bit_memory->GetBits(bits, (*huf_offsets)[ctx_offsets[i]].min_len);
			h_tmp = (*huf_offsets)[ctx_offsets[i]].DecodeFast(bits);

			while(h_tmp < 0)
			{
				bit_memory->GetBit(bits);
				h_tmp = (*huf_offsets)[ctx_offsets[i]].Decode(bits);
			}
			packed_offsets[i].push_back(h_tmp);
		}

	RLE0UnPack(packed_offsets[0], raw_packed_offsets0_size, TAG_RANGE_0, TAG_RANGE_0, 0);

	packed_offsets0_size = (uint32) packed_offsets[0].size();

	int64 prev_off = 0;
	int64 off;
	for(i = 0, j = 0; i < packed_offsets0_size; ++i)
	{
		if(packed_offsets[0][i] == TAG_PSEUDO_MATCH_N)
		{
			offsets.push_back(make_pair(TAG_PSEUDO_MATCH_N, 0));
			continue;
		}
		else if(packed_offsets[0][i] == TAG_PSEUDO_MATCH_n)
		{
			offsets.push_back(make_pair(TAG_PSEUDO_MATCH_n, 0));
			continue;
		}
		else if(packed_offsets[0][i] == TAG_SEQ_AUG)
		{
			offsets.push_back(make_pair(TAG_SEQ_AUG, ((int64) packed_offsets[1][j] << 24) + ((int64) packed_offsets[2][j] << 16) + ((int64) packed_offsets[3][j] << 8) + (int64) packed_offsets[4][j]));
			j++;
			continue;
		}
		else if(packed_offsets[0][i] < TAG_SEQ_REF_SEL)
			off = packed_offsets[0][i]-TAG_RANGE_0;
		else
		{
			off = ((int64) packed_offsets[1][j] << 24) + ((int64) packed_offsets[2][j] << 16) + ((int64) packed_offsets[3][j] << 8) + (int64) packed_offsets[4][j];
			if(packed_offsets[0][i] == TAG_LARGE_MINUS || (packed_offsets[0][i] - TAG_SEQ_REF_SEL) % 2 == 0)
				off = -off;
			j++;
		}

		offsets.push_back(make_pair(packed_offsets[0][i], off+prev_off));
		prev_off = off+prev_off;
	}

	return;
}

// ********************************************************************************************
void CBlock::Restart()
{
	int i;

	packed_flags.clear();
	packed_literals.clear();
	for(i = 0; i < 2; ++i)
		packed_lens[i].clear();
	for(i = 0; i < 5; ++i)
		packed_offsets[i].clear();
	flags.clear();
	literals.clear();
	lens.clear();
	offsets.clear();

	bit_memory->Restart();
}

// ********************************************************************************************
void CBlock::StartGetFlag()
{
	 flags_pos    = 0;
	 literals_pos = 0;
	 lens_pos     = 0;
	 offsets_pos  = 0;
}

// ********************************************************************************************
void CBlock::RLE0Pack(vector<uchar> &offsets, uchar s0, uchar s0a, uchar s0b)
{
	vector<uchar> pck;
	int32 len_0 = 0;

	for(int32 i = 0; i < offsets.size(); ++i)
	{
		if(offsets[i] == s0)
			len_0++;
		else
		{
			if(len_0)
			{
				RLE0PackLen(pck, len_0, s0a, s0b);
				len_0 = 0;
			}
			pck.push_back(offsets[i]);
		}
	}

	if(len_0)
		RLE0PackLen(pck, len_0, s0a, s0b);
	offsets.swap(pck);
}

// ********************************************************************************************
void CBlock::RLE0UnPack(vector<uchar> &offsets, uint32 raw_size, uchar s0, uchar s0a, uchar s0b)
{
	vector<uchar> unpck;
	int32 len_0 = 0;
	int32 r = 0;
	int32 pos = 0;

	unpck.reserve(raw_size);

	for(int32 i = 0; i < offsets.size(); ++i)
	{
		if(offsets[i] == s0a || offsets[i] == s0b)
		{
			if(offsets[i] == s0a)
				r |= 1 << pos;
			pos++;
		}
		else if(pos)
		{
			len_0 = r + (1 << pos) - 1;
			for(int32 j = 0; j < len_0; ++j)
				unpck.push_back(s0);
			pos = 0;
			r = 0;
			unpck.push_back(offsets[i]);
		}
		else
			unpck.push_back(offsets[i]);
	}

	if(pos)
	{
		len_0 = r + (1 << pos) - 1;			
		for(int32 j = 0; j < len_0; ++j)
			unpck.push_back(s0);
	}

	offsets.swap(unpck);
}

// ********************************************************************************************
void CBlock::RLE0PackLen(vector<uchar> &data, int32 len, uchar s0a, uchar s0b)
{
	int32 m = len+1;

	while(m & (m-1))
		m &= m-1;

	int mp = len+1 - m;

	for(int32 i = 0; (m & (1 << i)) == 0; ++i)
	{
		if(mp & (1 << i))
			data.push_back(s0a);
		else
			data.push_back(s0b);
	}
}
