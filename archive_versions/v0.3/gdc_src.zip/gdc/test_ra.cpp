// test_ra.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <iostream>
#include <fstream>
#include <iterator>
#include <string>
#include <algorithm>
#include <bitset>
#include <numeric>
#include <time.h>
#include <ctype.h>
#include <vector>
#include <assert.h>

#include "../gdc/compressor.h"
#include "../gdc/fasta.h"

CGDC *gdc;

int ref_mode;
int part_size;
int n_trials;
string archive_name;

using namespace std;

void show_usage();
bool parse_parameters(int argc, char *argv[]);
bool test_ra();

// ******************************************************************************
void show_usage()
{
	cout << "GDC - test random access\n";
	cout << "Usage: test_ra [options] <archive_name>\n";
	cout << "  archive_name - name of the archive file (created by GDC)\n";
	cout << "  options:\n";
	cout << "    -rX - r.a. mode, where X:\n";
	cout << "      0 - ref. seq. is compressed (default)\n";
	cout << "      1 - ref. seq. is decompressed (possible for better compress mode)\n";
	cout << "    -pX - part size from range [1, 10^5] (default: 100)\n";
	cout << "    -tX - no. of trials (default: 1000)\n";
	cout << "Examples:\n";
	cout << "  test_ra -p100 -t10000 para\n";
}

// ******************************************************************************
bool parse_parameters(CGDC *gdc, int argc, char *argv[])
{
	int32 i;

	if(argc < 2)
		return false;

	ref_mode  = 0;
	part_size = 100;
	n_trials  = 1000;

	for(i = 1; i < argc && argv[i][0] == '-'; ++i)
	{
		if(strncmp(argv[i], "-p", 2) == 0)
		{
			char *p1 = argv[i]+2;
			part_size = atoi(p1);
			if(part_size < 1 || part_size > 100000)
				part_size = 100;
		}
		else if(strncmp(argv[i], "-t", 2) == 0)
		{
			char *p1 = argv[i]+2;
			n_trials = atoi(p1);
			if(n_trials < 1 || n_trials > 1000000)
				n_trials = 1000;
		}
		if(strncmp(argv[i], "-r", 2) == 0)
		{
			ref_mode = argv[i][2] - '0';
			if(ref_mode < 0 || ref_mode > 1)
				ref_mode = 0;
		}
	}

	// No archive name
	if(argc < i+1)
		return false;

	archive_name = string(argv[i]);

	return true;
}

// ******************************************************************************
bool test_ra()
{
	vector<CGDCSequenceDesc> contents;
	if(!gdc->StartExtract(archive_name, contents, ref_mode != 0))
	{
		cout << "Invalid archive format, e.g., random access is not supported for\n";
		cout << "more than 1 reference sequence\n";
		return false;
	}

	string file_name;

	uchar *data;
	int len;

	vector<int> ra_col_id;
	vector<int> ra_seq_id;
	vector<int> ra_start_pos;

	srand(1);
	// Prepare random queries
	for(int i = 0; i < n_trials; ++i)
	{
		ra_col_id.push_back(rand() % contents.size());
		ra_seq_id.push_back(rand() % contents[ra_col_id.back()].sizes.size());

		if(contents[ra_col_id.back()].sizes[ra_seq_id.back()] < (uint32) part_size+1)
		{
			ra_col_id.pop_back();
			ra_seq_id.pop_back();
			i--;
			continue;
		}
		ra_start_pos.push_back(((rand() << 15) + rand()) % (contents[ra_col_id.back()].sizes[ra_seq_id.back()]-part_size-1));
	}

	clock_t t0 = clock();
	for(int i = 0; i < n_trials; ++i)
	{
		gdc->Read(ra_col_id[i], ra_seq_id[i], ra_start_pos[i], ra_start_pos[i]+part_size-1, data, len);
		delete[] data;
	}
	double dt = (double) (clock() - t0) / CLOCKS_PER_SEC;
	cout << "Parts of size: " << part_size << " B\n";
	cout << "No. of trials: " << n_trials << "\n";
	cout << "Total time:           " << dt << " s\n";
	cout << "Avg. time per query:  " << 1000.0 * dt / n_trials << " ms\n";
	cout << "Avg. time per symbol: " << 1000000.0 * dt / n_trials / part_size << " us\n";

	gdc->FinishExtract();

	return true;
}

// ******************************************************************************
int _tmain(int argc, _TCHAR* argv[])
{
#ifdef WIN32
	_CrtSetDbgFlag ( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif
	clock_t t0 = clock();

	gdc = new CGDC;

	if(!parse_parameters(gdc, argc, argv))
	{
		show_usage();
		delete gdc;
		return 0;
	}

	test_ra();

	getchar();

	delete gdc;
	return 0;
}

