/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Author: Sebastian Deorowicz
  
  Version: 0.3
  Date   : 2011-Aug-05
*/

#include "stdafx.h"
#include <algorithm>
#include <iostream>
#include <math.h>
#include "ref.h"
#include "utils.h"
#include <map>
#include <assert.h>

uint32 CReference::MEMORY_POOL_MAX_SIZE = 32;

// ********************************************************************
CRefBlock::CRefBlock()
{
	seq_comp		  = NULL;
}

// ********************************************************************
CRefBlock::~CRefBlock()
{
}


// ********************************************************************
//
// ********************************************************************
CReference::CReference()
{
	raw_seq_ref  = NULL;
	seq_ref_size = 0;

	raw_seq_pck  = NULL;
	seq_pck_size = 0;
	raw_seq_pck_alloc = false;

	raw_seq_comp = NULL;

	raw_comp_seq_ref = NULL;
	comp_seq_ref_size = 0;

	memory_tmp = NULL;
	mp_pos     = 0;

	sigma        = 0;

	block_size_exp = 13;
	block_size = 1 << block_size_exp;
	block_size_mask = block_size - 1;

	bit_memory = NULL;
	huf		   = NULL;

	lut	    = NULL;
	raw_lut = NULL;

	pb = new CPackedBuffer;
}

// ********************************************************************
CReference::CReference(const CReference &y)
{
	CReference &x = const_cast<CReference &>(y);

	raw_seq_ref    = x.raw_seq_ref;
	x.raw_seq_ref  = NULL;
	raw_seq_pck	   = x.raw_seq_pck;
	x.raw_seq_pck  = NULL;
	raw_seq_pck_alloc = x.raw_seq_pck_alloc;
	x.raw_seq_pck_alloc = false;

	raw_seq_comp   = x.raw_seq_comp;
	x.raw_seq_comp = NULL;

	bit_memory   = x.bit_memory;
	x.bit_memory = NULL;
	huf		     = x.huf;
	x.huf		 = NULL;
	pb			 = x.pb;
	x.pb		 = NULL;

	memory_tmp   = x.memory_tmp;
	x.memory_tmp = NULL;

	compress_mode   = x.compress_mode;

	blocks.swap(x.blocks);
	memory_pool.swap(x.memory_pool);
	mp_pos = x.mp_pos;
	x.mp_pos = 0;
	block_starts.swap(x.block_starts);
}

// ********************************************************************
CReference::~CReference()
{
	if(raw_seq_pck && raw_seq_pck_alloc)
		delete[] raw_seq_pck;
	if(huf)
		delete huf;
	if(bit_memory)
		delete bit_memory;

	if(raw_seq_comp)
		delete[] raw_seq_comp;

	if(memory_tmp)
		delete[] memory_tmp;

	delete pb;

	for(int i = 0; i < memory_pool.size(); ++i)
		delete[] memory_pool[i].first;
	mp_pos = 0;

	if(release_ref)
		delete[] raw_seq_ref;

	if(lut)
		delete[] lut;
	if(raw_lut)
		delete[] raw_lut;
}

// ********************************************************************
bool CReference::SetRefSeq(uchar *_raw_seq_ref, uint32 _size)
{
	raw_seq_ref	 = _raw_seq_ref;
	seq_ref_size = _size;
	release_ref  = false;

	return true;
}

// ********************************************************************
bool CReference::SetCompRefSeq(uchar *_raw_comp_seq_ref, uint32 _size)
{
	raw_comp_seq_ref  = _raw_comp_seq_ref;
	comp_seq_ref_size = _size;

	return true;
}

// ********************************************************************
void CReference::SetBlockSize(uint32 _block_size_exp)
{
	block_size_exp = _block_size_exp;
	block_size = 1 << block_size_exp;
	block_size_mask = block_size - 1;
}

// ********************************************************************
void CReference::FindAlphabet()
{
	uint32 stat[256] = {0};

	for(uint32 i = 0; i < seq_ref_size; ++i)
		stat[raw_seq_ref[i]]++;

	multimap<uint32, uchar, greater<uint32> > tmm;

	for(int32 i = 0; i < 256; ++i)
		if(stat[i])
			tmm.insert(make_pair(stat[i], i));

	sigma = 0;
	for(multimap<uint32, uchar, greater<uint32> >::iterator p = tmm.begin(); p != tmm.end(); ++p)
	{
		coding[p->second] = sigma;
		alph[sigma] = p->second;
		sigma++;
	}
}

// ********************************************************************
bool CReference::Compress(uchar _compress_mode, string col_name, uchar *&seq_comp, uint32 &size)
{
	if(raw_seq_pck)
	{
		delete[] raw_seq_pck;
		raw_seq_pck_alloc = false;
	}

	if(!seq_ref_size)
	{
		seq_comp = NULL;
		size     = 0;
		return true;
	}

	FindAlphabet();

	compress_mode = _compress_mode;
	n_blocks = (seq_ref_size + block_size - 1) / block_size;
	block_starts.clear();
	block_starts.push_back(1);
	fill_n(stats, P_MAX_REF_LIT, 0);

	uint32 pck;
	
	if(compress_mode == 1)
		pck = int_log(P_MAX_REF_LIT, sigma);
	else
		pck = int_log(1 << 16, sigma);

	seq_pck_size = (seq_ref_size+pck-1) / pck + n_blocks+1;
	raw_seq_pck = new uint16[seq_pck_size];
	raw_seq_pck_alloc = true;
	
	uint32 seq_pck_pos = 1;
	uint32 seq_ref_pos  = 0;

	for(uint32 i = 0; i < n_blocks; ++i, seq_ref_pos += block_size)
	{
		uint32 j;
		uint32 max_j = (uint32) (i < n_blocks-1 ? block_size : seq_ref_size - i * block_size);
		bool only_N = true;
		bool only_n = true;

		for(j = 0; j < max_j; ++j)
		{
			only_N &= raw_seq_ref[seq_ref_pos+j] == 'N';
			only_n &= raw_seq_ref[seq_ref_pos+j] == 'n';
		}

		if(only_N)
			block_starts.push_back((int64) seq_pck_pos);
		else if(only_n)
			block_starts.push_back(-(int64) seq_pck_pos);
		else
		{
			if(compress_mode == 1)
				pb->SetBufs(sigma, P_MAX_REF_LIT, raw_seq_ref+seq_ref_pos, raw_seq_pck+seq_pck_pos, max_j, 0);
			else
				pb->SetBufs(sigma, 1 << 16, raw_seq_ref+seq_ref_pos, raw_seq_pck+seq_pck_pos, max_j, 0);
			pb->EncodeP(coding);

			uint32 max_jj = (max_j + pck - 1) / pck;
			if(compress_mode == 1)
				for(j = 0; j < max_jj; ++j)
					stats[raw_seq_pck[seq_pck_pos+j]]++;
			seq_pck_pos += max_jj;
			block_starts.push_back(seq_pck_pos);
		}
	}

	uchar *huf_mem;
	uint32 huf_mem_size;

	if(compress_mode == 1)
	{
		if(huf)
			delete huf;
		huf = new CHuffman(P_MAX_REF_LIT);
		for(uint32 i = 0; i < P_MAX_REF_LIT; ++i)
			huf->Insert(stats[i]);
		huf->Complete();

		if(bit_memory)
			delete bit_memory;
		bit_memory = new CBitMemory();
		bit_memory->Create();
		for(uint32 i = 0; i < block_starts.size()-1; ++i)
		{
			uint32 start_pos = (uint32) ABS(block_starts[i]);
			uint32 stop_pos  = (uint32) ABS(block_starts[i+1]);

			if(block_starts[i] > 0)
				block_starts[i] = (int32) bit_memory->mem_buffer_pos;
			else
				block_starts[i] = (int32) -bit_memory->mem_buffer_pos;

			for(uint32 j = start_pos; j < stop_pos; ++j)
				bit_memory->PutBits(huf->codes[raw_seq_pck[j]].code, huf->codes[raw_seq_pck[j]].len);
			bit_memory->FlushPartialWordBuffer();
		}
		if(block_starts[block_starts.size()-1] > 0)
			block_starts[block_starts.size()-1] = (int32) bit_memory->mem_buffer_pos;
		else
			block_starts[block_starts.size()-1] = (int32) -bit_memory->mem_buffer_pos;

		bit_memory->Complete();

		delete[] raw_seq_pck;
		raw_seq_pck = NULL;
		raw_seq_pck_alloc = false;

		huf->StoreTree(huf_mem, huf_mem_size);

		size = (uint32) (3*sizeof(uchar) + sigma*sizeof(uchar) + 4*sizeof(uint32) + huf_mem_size + bit_memory->mem_buffer_pos + sizeof(uint32)*block_starts.size());
	}
	else
		size = (uint32) (3*sizeof(uchar) + sigma*sizeof(uchar) + 4*sizeof(uint32) + 2*(seq_pck_pos-1) + sizeof(uint32)*block_starts.size()) + 3;
	
	uint32 seq_pos = 0;
	seq_comp = new uchar[size];

	// Alphabet
	seq_comp[seq_pos++] = (uchar) block_size_exp;
	seq_comp[seq_pos++] = compress_mode;
	seq_comp[seq_pos++] = (uchar) sigma;
	memcpy(seq_comp+seq_pos, alph, sigma*sizeof(uchar));							seq_pos += sigma*sizeof(uchar);

	if(compress_mode == 1)
	{
		memcpy(seq_comp+seq_pos, &huf_mem_size, sizeof(uint32));					seq_pos += sizeof(uint32);
	}

	uint32 tmp;
	
	if(compress_mode == 1)
		tmp = (uint32) bit_memory->mem_buffer_pos;
	else
		tmp = (uint32) 2*(seq_pck_pos-1);
	memcpy(seq_comp+seq_pos, &tmp, sizeof(uint32));									seq_pos += sizeof(uint32);
	tmp = seq_ref_size;
	memcpy(seq_comp+seq_pos, &tmp, sizeof(uint32));									seq_pos += sizeof(uint32);
	tmp = (uint32) block_starts.size();
	memcpy(seq_comp+seq_pos, &tmp, sizeof(uint32));									seq_pos += sizeof(uint32);

	int32 *tblock_starts = new int32[block_starts.size()];
	copy(block_starts.begin(), block_starts.end(), tblock_starts);
	memcpy(seq_comp+seq_pos, tblock_starts, sizeof(int32)*block_starts.size());		seq_pos += (uint32) (sizeof(int32) * block_starts.size());
	delete[] tblock_starts;

	while((compress_mode == 0) && (seq_pos % 4))
		++seq_pos;

	if(compress_mode == 1)
	{
		memcpy(seq_comp+seq_pos, huf_mem, huf_mem_size);								seq_pos += huf_mem_size;
		memcpy(seq_comp+seq_pos, bit_memory->mem_buffer, bit_memory->mem_buffer_pos);	seq_pos += (uint32) bit_memory->mem_buffer_pos;
	
		delete huf;
		huf = NULL;
		delete bit_memory;
		bit_memory = NULL;
	}
	else
	{
		memcpy(seq_comp+seq_pos, raw_seq_pck+1, 2*(seq_pck_pos-1));						seq_pos += (uint32) seq_pck_pos;
	}

	return true;
}

// ********************************************************************
bool CReference::Decompress(string col_name, uchar *&seq_comp, uint32 &size)
{
	uint32 huf_mem_size;
	uint32 mem_buf_size;
	uint32 tmp;
	uint32 seq_pos = 0;

	// Alphabet
	block_size_exp = raw_comp_seq_ref[seq_pos++];
	block_size     = 1 << block_size_exp;
	block_size_mask = block_size - 1;

	compress_mode = raw_comp_seq_ref[seq_pos];										seq_pos += sizeof(uchar);

	sigma = raw_comp_seq_ref[seq_pos];												seq_pos += sizeof(uchar);
	memcpy(alph, raw_comp_seq_ref+seq_pos, sigma*sizeof(uchar));					seq_pos += sigma*sizeof(uchar);

	if(compress_mode == 1)
		pb->Init(P_MAX_REF_LIT);
	else
		pb->Init(1 << 16);

	if(compress_mode == 1)
	{
		memcpy(&huf_mem_size, raw_comp_seq_ref+seq_pos, sizeof(uint32));				seq_pos += sizeof(uint32);
	}
	memcpy(&mem_buf_size, raw_comp_seq_ref+seq_pos, sizeof(uint32));				seq_pos += sizeof(uint32);

	memcpy(&tmp, raw_comp_seq_ref+seq_pos, sizeof(uint32));							seq_pos += sizeof(uint32);
	seq_ref_size = tmp;
	memcpy(&tmp, raw_comp_seq_ref+seq_pos, sizeof(uint32));							seq_pos += sizeof(uint32);
	n_blocks = tmp-1;

	int32 *tblock_starts = new int32[n_blocks+1];
	memcpy(tblock_starts, raw_comp_seq_ref+seq_pos, (n_blocks+1)*sizeof(int32));	seq_pos += (n_blocks+1) * sizeof(int32);
	block_starts.assign(tblock_starts, tblock_starts+n_blocks+1);
	delete[] tblock_starts;

	uint32 pck;
	
	if(compress_mode == 1)
		pck = int_log(P_MAX_REF_LIT, sigma);
	else
		pck = int_log(1 << 16, sigma);

	uchar *huf_mem;
	
	if(compress_mode == 1)
	{
		huf_mem = new uchar[huf_mem_size];			
		memcpy(huf_mem, raw_comp_seq_ref+seq_pos, huf_mem_size);						seq_pos += huf_mem_size;
		if(huf)
			delete huf;
		huf = new CHuffman(P_MAX_REF_LIT);
		huf->LoadTree(huf_mem, huf_mem_size);
	}

	if(raw_seq_pck)
		delete[] raw_seq_pck;
	seq_pck_size = (seq_ref_size+pck-1) / pck + n_blocks+1;
	raw_seq_pck = new uint16[seq_pck_size];
	raw_seq_pck_alloc = true;

	while((compress_mode == 0) && (seq_pos % 4))
		++seq_pos;

	if(compress_mode == 1)
	{
		if(bit_memory)
			delete bit_memory;
		bit_memory = new CBitMemory;
		bit_memory->Open(raw_comp_seq_ref+seq_pos, mem_buf_size);

		seq_pos = 0;

		for(uint32 i = 0; i < n_blocks; ++i)
		{
			uint32 start_pos = i*((block_size+pck-1)/pck);
			uint32 stop_pos  = start_pos + (block_size+pck-1)/pck;
			if(stop_pos > start_pos+(seq_ref_size-i*block_size+pck-1)/pck)
				stop_pos = start_pos+(seq_ref_size-i*block_size+pck-1)/pck;

			if(ABS(block_starts[i]) != ABS(block_starts[i+1]))
			{
				for(uint32 j = start_pos; j < stop_pos; ++j)
				{
					uint32 bits;
					int32 h_tmp = -1;
					int32 first_bits = huf->min_len;

					bit_memory->GetBits(bits, first_bits);
					h_tmp = huf->DecodeFast(bits);

					while(h_tmp < 0)
					{
						bit_memory->GetBit(bits);
						h_tmp = huf->Decode(bits);
					};
					raw_seq_pck[j] = h_tmp;
				}
				bit_memory->FlushInputWordBuffer();
			}
		}
		delete bit_memory;
		bit_memory = NULL;
		bit_memory = new CBitMemory;
	}
	else
	{
		for(uint32 i = 0; i < n_blocks; ++i)
		{
			uint32 start_pos = i*((block_size+pck-1)/pck);
			uint32 stop_pos  = start_pos + (block_size+pck-1)/pck;
			if(stop_pos > start_pos+(seq_ref_size-i*block_size+pck-1)/pck)
				stop_pos = start_pos+(seq_ref_size-i*block_size+pck-1)/pck;

			if(ABS(block_starts[i]) != ABS(block_starts[i+1]))
				memcpy(raw_seq_pck + start_pos, raw_comp_seq_ref + seq_pos + ABS(block_starts[i])*2-2, (stop_pos-start_pos)*2);
		}
	}

	seq_comp = new uchar[seq_ref_size+10];
	size = seq_ref_size;
	raw_seq_ref = seq_comp;
	release_ref = true;

	uint32 pos = 1;
	for(uint32 i = 0; i < n_blocks; ++i)
	{
		uint32 start_pos = i*((block_size+pck-1)/pck);
		uint32 stop_pos  = start_pos + (block_size+pck-1)/pck;
		if(stop_pos > start_pos+(seq_ref_size-i*block_size+pck-1)/pck)
			stop_pos = start_pos+(seq_ref_size-i*block_size+pck-1)/pck;

		uchar cN = 'N';
		if(block_starts[i+1] < 0)
			cN = 'n';

		if(ABS(block_starts[i]) == ABS(block_starts[i+1]))
		{
			start_pos = pos;
			stop_pos  = pos+block_size;
			if(stop_pos > seq_ref_size+1)
				stop_pos = seq_ref_size+1;
			for(uint32 j = start_pos; j < stop_pos; ++j)
				seq_comp[pos++] = cN;
		}
		else
		{
			if(compress_mode == 1)
				pb->SetBufs(sigma, P_MAX_REF_LIT, seq_comp+pos, raw_seq_pck+start_pos, block_size, stop_pos-start_pos);
			else
				pb->SetBufs(sigma, 1 << 16, seq_comp+pos, raw_seq_pck+start_pos, block_size, stop_pos-start_pos);
			pb->DecodeP(alph);
			pos += block_size;
		}
	}
	fill_n(seq_comp+seq_ref_size+1, 9, '*');

	if(compress_mode == 1)
	{
		delete huf;
		huf = NULL;
		delete huf_mem;
	}
	delete[] raw_seq_pck;
	raw_seq_pck = NULL;
	raw_seq_pck_alloc = false;

	return true;
}

// ********************************************************************
// Prepares to decompress for random access mode
bool CReference::PrepareDecompress(bool _ref_mode)
{
	uint32 huf_mem_size;
	uint32 mem_buf_size;
	uint32 tmp;
	uint32 seq_pos = 0;

	pb->Init(P_MAX_REF_LIT);

	// Alphabet
	block_size_exp = raw_comp_seq_ref[seq_pos];										seq_pos += sizeof(uchar);
	block_size     = 1 << block_size_exp;
	block_size_mask = block_size - 1;

	compress_mode = raw_comp_seq_ref[seq_pos];										seq_pos += sizeof(uchar);

	sigma = raw_comp_seq_ref[seq_pos];												seq_pos += sizeof(uchar);
	memcpy(alph, raw_comp_seq_ref+seq_pos, sigma*sizeof(uchar));					seq_pos += sigma*sizeof(uchar);

	if(compress_mode == 1)
	{
		memcpy(&huf_mem_size, raw_comp_seq_ref+seq_pos, sizeof(uint32));			seq_pos += sizeof(uint32);
	}
	memcpy(&mem_buf_size, raw_comp_seq_ref+seq_pos, sizeof(uint32));				seq_pos += sizeof(uint32);
	memcpy(&tmp, raw_comp_seq_ref+seq_pos, sizeof(uint32));							seq_pos += sizeof(uint32);
	seq_ref_size = tmp;
	memcpy(&tmp, raw_comp_seq_ref+seq_pos, sizeof(uint32));							seq_pos += sizeof(uint32);
	n_blocks = tmp;

	uint32 *tblock_starts = new uint32[n_blocks];
	memcpy(tblock_starts, raw_comp_seq_ref+seq_pos, n_blocks*sizeof(uint32));		seq_pos += n_blocks * sizeof(uint32);
	block_starts.assign(tblock_starts, tblock_starts+n_blocks);
	delete[] tblock_starts;
	blocks.resize(n_blocks-1);
	for(uint32 i = 0; i < n_blocks-1; ++i)
		blocks[i].is_compressed = true;

	if(compress_mode == 1)
		pck = int_log(P_MAX_REF_LIT, sigma);
	else
		pck = int_log(1 << 16, sigma);

	uchar *huf_mem;
	if(compress_mode == 1)
	{
		huf_mem = new uchar[huf_mem_size];			
		memcpy(huf_mem, raw_comp_seq_ref+seq_pos, huf_mem_size);						seq_pos += huf_mem_size;
		if(huf)
			delete huf;
		huf = new CHuffman(P_MAX_REF_LIT);
		huf->LoadTree(huf_mem, huf_mem_size);
	}

	if(memory_tmp)
		delete[] memory_tmp;
	memory_tmp = new uint16[(block_size + pck - 1) / pck];

	while((compress_mode == 0) && (seq_pos % 4))
		++seq_pos;

	if(compress_mode == 1)
	{
		if(bit_memory)
			delete bit_memory;
		bit_memory = new CBitMemory();
		bit_memory->Open(raw_comp_seq_ref+seq_pos, mem_buf_size);
	}
	else
	{
/*		if(raw_seq_pck)
			delete[] raw_seq_pck;
		seq_pck_size = (seq_ref_size+pck-1) / pck + n_blocks+1;
		raw_seq_pck = new uint16[seq_pck_size];
		memcpy(raw_seq_pck, raw_comp_seq_ref+seq_pos, mem_buf_size);*/
		seq_pck_size = (seq_ref_size+pck-1) / pck + n_blocks+1;
		raw_seq_pck = (uint16 *) (raw_comp_seq_ref+seq_pos);
		raw_seq_pck_alloc = false;
	}
	ra_seq_pos = seq_pos;

	if(raw_seq_comp)
		delete[] raw_seq_comp;
	if(compress_mode == 1)
		delete huf_mem;

	if(compress_mode == 0)
		PrepareLUT();

	for(uint32 i = 0; i < memory_pool.size(); ++i)
		delete[] memory_pool[i].first;
	memory_pool.clear();
	mp_pos = 0;

	// In faster-compression mode no full decompress is possible
	if(compress_mode == 0)
		_ref_mode = false;

	ref_mode = _ref_mode;
	if(ref_mode)
		for(int i = 0; i < blocks.size(); ++i)
			DecompressBlock(i);

	return true;
}

// ********************************************************************
bool CReference::DecompressBlock(uint32 block_id)
{
	if(!blocks[block_id].is_compressed)				// block not compressed?
		return true;

	uint32 pck = int_log(P_MAX_REF_LIT, sigma);
	uint32 start_pos = block_id*((block_size+pck-1)/pck);
	uint32 stop_pos  = start_pos + (block_size+pck-1)/pck;
	if(stop_pos > start_pos+(seq_ref_size-block_id*block_size+pck-1)/pck)
		stop_pos = start_pos+(seq_ref_size-block_id*block_size+pck-1)/pck;

	if(mp_pos >= memory_pool.size())
	{
		memory_pool.push_back(make_pair((uchar *) NULL, block_id));
		memory_pool.back().first = new uchar[block_size];
	}

	blocks[block_id].seq_comp = memory_pool[mp_pos].first;
	memory_pool[mp_pos].second = block_id;
	mp_pos++;

	if(start_pos < stop_pos)
	{
		bit_memory->Open(raw_comp_seq_ref+ra_seq_pos+block_starts[block_id], block_starts[block_id+1]-block_starts[block_id], true);

		for(uint32 j = 0; j < stop_pos-start_pos; ++j)
		{
			uint32 bits;
			int32 h_tmp = -1;
			int32 first_bits = huf->min_len;

			bit_memory->GetBits(bits, first_bits);
			h_tmp = huf->DecodeFast(bits);

			while(h_tmp < 0)
			{
				bit_memory->GetBit(bits);
				h_tmp = huf->Decode(bits);
			}
			memory_tmp[j] = h_tmp;
		}
		bit_memory->FlushInputWordBuffer();
	}

	uint32 pos = block_id*block_size+1;
	uchar cN = 'N';
	if(block_starts[block_id+1] < 0)
		cN = 'n';

	if(start_pos == stop_pos)
		for(uint32 j = 0; j < block_size; ++j)
			if(pos > seq_ref_size)
				break;
			else
				blocks[block_id].seq_comp[j] = cN;
	else
	{
		pb->SetBufs(sigma, P_MAX_REF_LIT, blocks[block_id].seq_comp, memory_tmp, block_size, stop_pos-start_pos);
		pb->DecodeP(alph);
	}

	blocks[block_id].is_compressed = false;
	return true;
}

// ********************************************************************
void CReference::StartRead()
{
	if(ref_mode)
		return;

	for(uint32 i = 0; i < mp_pos; ++i)
		blocks[memory_pool[i].second].is_compressed = true;

	while(memory_pool.size() > MEMORY_POOL_MAX_SIZE)
	{
		delete[] memory_pool.back().first;
		memory_pool.pop_back();
	}
	mp_pos = 0;
}

// ********************************************************************
bool CReference::DecompressRange(uint32 extr_from, uint32 extr_to)
{
	int32 start_block_id;
	int32 end_block_id;
	int32 i;

	start_block_id = extr_from / block_size;
	end_block_id   = extr_to / block_size;

	for(i = start_block_id; i <= end_block_id; ++i)
		DecompressBlock(i);

	return true;
}

// ********************************************************************
void CReference::PrepareLUT()
{
	if(lut)
		delete[] lut;
	if(raw_lut)
		delete[] raw_lut;

	uint32 i, j;

	if(sigma == 0)
		return;

	uint32 max_val = 1;
	for(i = 0; i < pck; ++i)
		max_val *= sigma;

	raw_lut = new uchar[max_val*pck];
	lut     = new uchar*[max_val];
	
	lut[0] = &raw_lut[0];
	for(i = 1; i < max_val; ++i)
		lut[i] = lut[i-1] + pck;

	fill_n(lut[0], pck, 0);

	for(i = 1; i < max_val; ++i)
	{
		copy_n(lut[i-1], pck, lut[i]);
		for(j = pck-1; j >= 0; --j)
		{
			if(lut[i][j] < sigma-1)
			{
				lut[i][j]++;
				break;
			}
			else
				lut[i][j] = 0;
		}
	}

	for(i = 0; i < max_val*pck; ++i)
		raw_lut[i] = alph[raw_lut[i]];
}
