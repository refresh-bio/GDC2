/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Author: Sebastian Deorowicz
  
  Version: 0.3
  Date   : 2011-Aug-05
*/

#pragma once
/*#define _CRT_SECURE_NO_WARNINGS

#include "targetver.h"

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#ifdef _DEBUG
   #ifndef DBG_NEW
      #define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
      #define new DBG_NEW
   #endif
#endif  // _DEBUG
*/
#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here
