#include "stdafx.h"
/*
  This file is a part of GDC software distributed under GNU GPL 2 licence.
  The homepage of the GDC project is http://sun.aei.polsl.pl/gdc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  
  Version: 0.2
  Date   : 2011-May-04
*/

#include "sequence.h"
#include <algorithm>
#include <numeric>
#include <assert.h>
#include "utils.h"

using namespace std;

int32 CSequence::OFF_COST_1 = 8;
int32 CSequence::OFF_COST_2 = 8;
int32 CSequence::OFF_COST_3 = 8;
double BEST_LEN_MOD_DIV		= 128;
int32 MISMATCH_PENALTY		= 6; 

// ********************************************************************************************
CSequence::CSequence(string _col_name, CPackedBuffer *_pbf, CPackedBuffer *_pbl)
{
	col_name = _col_name;

	seq = NULL;
	comp_seq = NULL;

	min_match_1st_len   = 13;
	min_match_ext_len   = 4;
	min_match_total_len = 13;

	min_aug_len         = 32;

	block_size_exp	    = 30;
	block_size			= 1 << block_size_exp;

	pbf = _pbf;
	pbl = _pbl;
}

// ********************************************************************************************
CSequence::~CSequence()
{
//	delete pbf;
//	delete pbl;
	delete[] comp_seq;

	for(uint32 i = 0; i < blocks.size(); ++i)
		if(blocks[i])
			delete blocks[i];

	// Do not delete seq
}

// ********************************************************************************************
bool CSequence::SetParams(int32 _min_match_1st_len, int32 _min_match_ext_len, int32 _min_match_total_len, int32 _min_aug_len, int32 _block_size_exp)
{
	min_match_1st_len   = _min_match_1st_len;
	min_match_ext_len   = _min_match_ext_len;
	min_match_total_len = _min_match_total_len;
	min_aug_len         = _min_aug_len;

	block_size_exp      = _block_size_exp;
	block_size   	    = 1 << block_size_exp;

	return true;
}

// ********************************************************************************************
bool CSequence::SetSeq(uchar *_seq, uint32 size)
{
	seq		 = _seq;
	seq_size = size;

	return true;
}

// ********************************************************************************************
bool CSequence::GetUnSequence(uchar *&_seq_decomp, uint32 &len_decomp)
{
	if(extr_from == -1)
	{
		_seq_decomp = seq_decomp.mem_buffer;
		len_decomp  = (uint32) seq_decomp.mem_buffer_pos;
		seq_decomp.TakeOwnership();
	}
	else
	{
		_seq_decomp = seq_decomp.mem_buffer;
		len_decomp  = (uint32) (extr_to - extr_from + 2);
	}

	return true;
}

// ********************************************************************************************
bool CSequence::SetHasher(CHasher *_hasher)
{
	hasher = _hasher;

	return true;
}

// ********************************************************************************************
bool CSequence::AddSeqRef(CReference *_ref)
{
	refs.push_back(_ref);
	
	return true;
}

// ********************************************************************************************
int32 CSequence::NRunLen(uint32 pos)
{
	uint32 r = 0;

	uchar cN = seq[pos];

	if(cN != 'N' && cN != 'n')
		return 0;

	for(; seq[pos+r] == cN; ++r)
		;

	if(r < (uint32) min_match_1st_len)
		return 0;
	else if(cN == 'N')
		return (int32) r;
	else
		return - ((int32) r);
}

// ********************************************************************************************
// Process seq - only find matches and compute statistics
bool CSequence::Process()
{
	uint32 i, j;
	for(i = 0; i < blocks.size(); ++i)
		if(blocks[i])
			delete blocks[i];
	blocks.clear();
	block_starts.clear();

	int64 block_end = 0;

	int64 off_to_write = ((int64) 1) << 35;
	int64 prev_off_to_write = ((int64) 1) << 36;
	uint32 literals_start = 0;
	int32 col_id;
	vector<int32> lens;
	vector<int32> best_lens;
	vector<uchar> chars, non_chars;
	int32 best_col_id = 1, prev_col_id = 1;

	uint32 traf[2] = {0};
	uchar last_exc_char = ' ';

	uint32 next_rap_pos = 0;
	uint32 rap_step = 1 << 22;
	int32 cost_matrix[2][2][2][2] = 
		{{{{0, -OFF_COST_2},                                        {-OFF_COST_3, -OFF_COST_1-OFF_COST_2}},
		{{OFF_COST_2, 0},                                           {-OFF_COST_3+OFF_COST_2, -OFF_COST_1}}},
		{{{OFF_COST_3, OFF_COST_3-OFF_COST_2},                      {0, -OFF_COST_1}},
		{{OFF_COST_1+OFF_COST_2, OFF_COST_1-OFF_COST_2+OFF_COST_3}, {OFF_COST_1, 0}}}};
	double cost_modifier = 1.0;

	tot_best_tnd = tot_tnd = tot_periods = tot_lit = 0;

	int64 tot_match_len = 0;
	int64 n_tot_match   = 0;
	int64 tot_part_len  = 0;
	int64 n_tot_part    = 0;

	double avg_match_len = min_match_1st_len;
	double avg_part_len = min_match_1st_len;

	seq[0] = 0;

	for(i = 0; i <= seq_size;)
	{
		if(i >= next_rap_pos)
		{
			report(string(col_name) + ": compressing:", (uint32) i, seq_size+1, false);
			next_rap_pos += rap_step;
		}

		if(i >= block_end)
		{
			if(literals_start)
				AddLiterals(literals_start, i, last_exc_char);
			last_exc_char = ' ';
			block_starts.push_back(i);
			blocks.push_back(new CBlock(min_match_1st_len, min_match_ext_len));
			blocks.back()->SetParams(min_match_1st_len, min_match_ext_len, block_size_exp, pbf, pbl);
			block_end += (int64) block_size;
			off_to_write = ((int64) 1) << 35;
			prev_off_to_write = ((int64) 1) << 36;

			blocks.back()->col_name = (char *) (col_name.c_str());
			blocks.back()->seq_size = seq_size;
			blocks.back()->seq_start_block = i;
		}
		while((int64) i >= block_end)
			block_end += (int64) block_size;

		uint32 pos;
		uint32 best_pos = 0, best_len = 0;
		uint32 best_len1 = 0, best_len2 = 0, best_len3 = 0;
		best_lens.clear();

		int32 N_run_len = NRunLen(i);
		if(N_run_len)
		{
			best_pos = 0;
			best_len = best_len1 = N_run_len;
			best_lens.push_back(ABS(N_run_len));
		}
		
		if(N_run_len)
		{
			if(literals_start)
			{
				AddLiterals(literals_start, i, last_exc_char);
				last_exc_char = ' ';
			}
			if(N_run_len > 0)
			{
				blocks.back()->AddMatch(TAG_PSEUDO_MATCH_N, 0, best_lens[0]);
				last_exc_char = 'N';
			}
			else
			{
				blocks.back()->AddMatch(TAG_PSEUDO_MATCH_n, 0, best_lens[0]);
				last_exc_char = 'n';
			}
			i += (uint32) best_lens[0];
		}
		else if(hasher->FindFirst(seq+i, N_MISMATCHES, pos, lens, col_id, literals_start == 0))
		{
			best_col_id = prev_col_id;
			do
			{
				int32 sum_len = accumulate(lens.begin(), lens.end(), 0);
				int32 best_len_mod = 0;

				bool best_is_col_same = best_col_id == prev_col_id;
				bool best_is_small    = ABS(prev_off_to_write - off_to_write) < (int64) TAG_RANGE_0;
				bool act_is_col_same  = col_id == prev_col_id;
				bool act_is_small     = ABS(prev_off_to_write - ((int64) pos - (int64) i)) < (int64) TAG_RANGE_0;

				best_len_mod = (int32) (cost_matrix[best_is_col_same][best_is_small][act_is_col_same][act_is_small] * cost_modifier);

				if(sum_len >= min_match_total_len && sum_len - lens.size()*MISMATCH_PENALTY > best_len + best_len_mod - best_lens.size()*MISMATCH_PENALTY)
				{
					best_col_id = col_id;
					best_len  = sum_len;
					if(col_id == 0)			// aug. seq.
					{
						best_pos  = pos;
						off_to_write = best_pos;
					}
					else
					{
						best_pos  = pos;
						off_to_write = (int64) best_pos - (int64) i;
					}
					best_lens.swap(lens);
				}
			} while(hasher->FindNext(seq+i, N_MISMATCHES, pos, lens, col_id));

			if(best_lens.empty())
			{
				if(!literals_start)
					literals_start = i;
				++i;
			}
			else
			{
				if(literals_start)
				{
					AddLiterals(literals_start, i, last_exc_char);
					last_exc_char = ' ';
				}

				chars.clear();
				non_chars.clear();
				int64 s_pos = -1;
				for(j = 0; j < best_lens.size()-1; ++j)
				{
					s_pos += best_lens[j]+1;
					chars.push_back(seq[(int64) i + s_pos]);
					if(best_col_id == 0)
						non_chars.push_back(hasher->seqs_ref[0][off_to_write+s_pos]);
					else
						non_chars.push_back(hasher->seqs_ref[best_col_id][off_to_write+(int64)i+s_pos]);
				}
				s_pos += best_lens.back()+1;

				tot_match_len += (int32) best_len;
				n_tot_match++;
				tot_part_len += (int32) best_len;
				n_tot_part += (int32) best_lens.size();
				avg_match_len = (double) tot_match_len / n_tot_match;
				avg_part_len = (double) tot_part_len / n_tot_part;
				cost_modifier = 1 + avg_part_len / BEST_LEN_MOD_DIV;

				if(best_col_id == 0)
					last_exc_char = ' ';
				else
					last_exc_char = hasher->seqs_ref[best_col_id][off_to_write+(int64)i+s_pos];

				if(best_col_id == 0)
					blocks.back()->AddMatch(TAG_SEQ_AUG, off_to_write, best_lens, chars, non_chars);
				else
				{
					if(best_col_id == prev_col_id)
						blocks.back()->AddMatch(0, off_to_write, best_lens, chars, non_chars);
					else
						blocks.back()->AddMatch(TAG_SEQ_REF_SEL+best_col_id, off_to_write, best_lens, chars, non_chars);
				}
				i += (uint32) (accumulate(best_lens.begin(), best_lens.end(), 0) + (uint32) chars.size());
				if(best_col_id > 0)
				{
					prev_off_to_write = off_to_write;
					prev_col_id = best_col_id;
				}
				literals_start = 0;
			}
		}
		else
		{
			if(!literals_start)
				literals_start = i;
			++i;
		}
	}

	if(literals_start)
		AddLiterals(literals_start, i, last_exc_char);

	return true;
}

// ********************************************************************************************
bool CSequence::AdjustMaxs()
{
	int32 i;
	uint32 n_flags    = 0;
	uint32 n_literals = 0;
	uint32 n_lens	  = 0;
	uint32 n_offsets  = 0;

	for(i = 0; i < blocks.size(); ++i)
	{
		n_flags    += (uint32) blocks[i]->flags.size();
		n_literals += (uint32) blocks[i]->literals.size();
		n_lens     += (uint32) blocks[i]->lens.size();
		n_offsets  += (uint32) blocks[i]->offsets.size();
	}

	if(n_flags < (1 << 13))
		P_FLAG_MAX_EXP = 8;
	else if(n_flags < (1 << 16))
		P_FLAG_MAX_EXP = 12;
	else 
		P_FLAG_MAX_EXP = 15;

	if(n_literals < (1 << 15))
		P_LIT_MAX_EXP = 8;
	else if(n_literals < (1 << 17))
		P_LIT_MAX_EXP = 10;
	else if(n_literals < (1 << 18))
		P_LIT_MAX_EXP = 12;
	else
		P_LIT_MAX_EXP = 12;

	P_FLAG_MAX = 1 << P_FLAG_MAX_EXP;
	P_LIT_MAX  = 1 << P_LIT_MAX_EXP;

	pbf->Init(P_FLAG_MAX);
	pbl->Init(P_LIT_MAX);

	if(n_lens < (1 << 12))
		S_LENS = 1;
	else
		S_LENS = 2;

	if(n_offsets < (1 << 12))
		S_OFFSETS = 2;
	else if(n_offsets < (1 << 15))
		S_OFFSETS = 3;
	else if(n_offsets < (1 << 17))
		S_OFFSETS = 4;
	else
		S_OFFSETS = 5;	

	for(i = 0; i < blocks.size(); ++i)
	{
		blocks[i]->P_FLAG_MAX = P_FLAG_MAX;
		blocks[i]->P_LIT_MAX  = P_LIT_MAX;
		blocks[i]->S_LENS	 = S_LENS;
		blocks[i]->S_OFFSETS	 = S_OFFSETS;
	}

	return true;
}

// ********************************************************************************************
void CSequence::AddLiterals(uint32 &literals_start, uint32 cur_pos, uchar last_exc_char)
{
	uint32 i;

	if(cur_pos - literals_start <= (uint32) min_aug_len)
	{
		if(cur_pos-literals_start < (uint32) LIT_MIN)
			for(i = literals_start; i < cur_pos; ++i)
			{
				blocks.back()->AddLiteral(seq[i], last_exc_char);
				last_exc_char = ' ';
			}
		else
			blocks.back()->AddLiterals(seq+literals_start, cur_pos-literals_start, last_exc_char);
	}
	else
	{
		blocks.back()->AddMatch(TAG_SEQ_AUG, (int64) (hasher->seqs_size[0]), (int32) (cur_pos-literals_start));
		hasher->AppendAugSeq(seq+literals_start, (int32) (cur_pos-literals_start));
	}

	literals_start = 0;
}

// ********************************************************************************************
// Make precompression of blocks
// Must be executed after process()
bool CSequence::PreCompress(uint32 _sigma, uchar *_alph, uchar *_lit_coding,
	vector<int32> *_stat_flags, vector<int32> *_stat_literals, vector<vector<int32> > *_stat_lens, vector<vector<int32> > *_stat_offsets)
{
	stat_flags    = _stat_flags;
	stat_literals = _stat_literals;
	stat_lens     = _stat_lens;
	stat_offsets  = _stat_offsets;
	
	sigma         = _sigma;
	alph		  = _alph;
	lit_coding	  = _lit_coding;

	stat_flags->assign(P_FLAG_MAX, 0);
	stat_literals->assign(P_LIT_MAX, 0);

	for(uint32 i = 0; i < blocks.size(); ++i)
	{
		blocks[i]->SetStatTables(stat_flags, stat_literals, stat_lens, stat_offsets);
		blocks[i]->lit_coding = lit_coding;
		blocks[i]->alph       = alph;
		blocks[i]->sigma      = sigma;
		blocks[i]->PreCompress();
	}

	return true;
}

// ********************************************************************************************
bool CSequence::Compress()
{
	uint32 i, j;

	huf_flags.Restart(P_FLAG_MAX);
	for(i = 0; i < P_FLAG_MAX; ++i)
		huf_flags.Insert((*stat_flags)[i]);
	huf_flags.Complete();

	huf_literals.Restart(P_LIT_MAX);
	for(i = 0; i < P_LIT_MAX; ++i)
		huf_literals.Insert((*stat_literals)[i]);
	huf_literals.Complete();
	
	huf_lens.resize(S_LENS);
	for(uint32 i = 0; i < S_LENS; ++i)
	{
		huf_lens[i].Restart(256);
		for(j = 0; j < 256; ++j)
			huf_lens[i].Insert((*stat_lens)[i][j]);
		huf_lens[i].Complete();
	}

	huf_offsets.resize(S_OFFSETS);
	for(uint32 i = 0; i < S_OFFSETS; ++i)
	{
		huf_offsets[i].Restart(256);
		for(j = 0; j < 256; ++j)
			huf_offsets[i].Insert((*stat_offsets)[i][j]);
		huf_offsets[i].Complete();
	}

	for(i = 0; i < blocks.size(); ++i)
	{
		blocks[i]->SetHuffmans(&huf_flags, &huf_literals, &huf_lens, &huf_offsets);
		blocks[i]->Compress();
	}
	
	return true;
}

// ********************************************************************************************
bool CSequence::UnProcess()
{
	uchar c1;
	int64 offset;
	int32 len1;
	uchar tag;

	seq_decomp.Create();
	seq_decomp.PutByte(' ');
	uint32 pos = 1;
	vector<uchar> chars;
	vector<int32> lens;
	uchar last_exc_char = ' ';
	uint32 col_id = 1;
	uint32 prev_col_id = 1;

	extr_b_start = 0;
	extr_b_end   = (int32) blocks.size()-1;

	pos = block_starts[extr_b_start];
	for(int32 i = extr_b_start; i <= extr_b_end; ++i)
	{
		blocks[i]->StartGetFlag();
		t_flag last_flag = 0;
		last_exc_char = ' ';
		for(t_flag flag = blocks[i]->GetFlag(); flag != N_FLAGS; flag = blocks[i]->GetFlag())
		{
			if(flag == 0)
// Single literal
			{
				blocks[i]->GetLiteral(c1);
				if(last_flag > 0 && last_flag < N_FLAGS-1)
				{					
					if(lit_coding[c1] < lit_coding[last_exc_char])
						seq_decomp.PutByte(c1);
					else
						seq_decomp.PutByte(alph[lit_coding[c1]+1]);
				}
				else
					seq_decomp.PutByte(c1);
				pos++;
				last_exc_char = ' ';
			}
			else if(flag == 1)
// *** Match (or pseudomatch) without mismatches
			{
				blocks[i]->GetMatch(tag, offset, len1);
				if(tag == TAG_PSEUDO_MATCH_N)
// *** Run of Ns
				{
					seq_decomp.PutNBytes('N', len1);
					last_exc_char = 'N';
				}
				else if(tag == TAG_PSEUDO_MATCH_n)
// *** Run of ns
				{
					seq_decomp.PutNBytes('n', len1);
					last_exc_char = 'n';
				}
// *** Match without mismatches
				else
				{
  // *** Match from aug. sequence
					if(tag == TAG_SEQ_AUG)
					{
						seq_decomp.PutBytes(refs[0]->raw_seq_ref+offset, len1);
						last_exc_char = ' ';
					}
  // *** Match from ref. sequence
					else
					{
						if(tag >= TAG_SEQ_REF_SEL && tag < TAG_SEQ_AUG)
							col_id = (tag - TAG_SEQ_REF_SEL) / 2 + 1;

						offset += pos;
						assert(offset >= 0 && offset < (int64) refs[col_id]->seq_ref_size);
						seq_decomp.PutBytes(refs[col_id]->raw_seq_ref+(int64)1+offset, len1);
						last_exc_char = refs[col_id]->raw_seq_ref[offset+(int64)1+(int64)len1];
					}
				}
				pos += (uint32) len1;
			}
			else if(flag == N_LIT)
// *** Many literals
			{
				blocks[i]->GetLiterals(chars);

				if(last_flag > 0 && last_flag < N_FLAGS-1)
				{					
					if(lit_coding[chars[0]] < lit_coding[last_exc_char])
						seq_decomp.PutByte(chars[0]);
					else
						seq_decomp.PutByte(alph[lit_coding[chars[0]]+1]);
					for(uint32 j = 1; j < chars.size(); ++j)
						seq_decomp.PutByte(chars[j]);
				}
				else
					for(uint32 j = 0; j < chars.size(); ++j)
						seq_decomp.PutByte(chars[j]);

				pos += (uint32) chars.size();
				last_exc_char = ' ';
			}
			else if(flag < N_MISMATCHES+2)
// *** Match with a number of mismatches
			{
				blocks[i]->GetMatch(flag, tag, offset, lens, chars);
				if(tag == TAG_SEQ_AUG)
  // *** Match with a number of mismatches from aug. sequence
				{
					seq_decomp.PutBytes(refs[0]->raw_seq_ref+offset, lens[0]);
					int64 s_pos = 0;
					for(int32 j = 1; j < (int32) lens.size(); ++j)
					{
						s_pos += lens[j-1];
						if(lit_coding[chars[j-1]] < lit_coding[refs[0]->raw_seq_ref[offset+s_pos]])
							seq_decomp.PutByte(chars[j-1]);
						else
							seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
						s_pos++;
						seq_decomp.PutBytes(refs[0]->raw_seq_ref+offset+s_pos, lens[j]);
					}
					last_exc_char = ' ';
				}
				else
  // *** Match with a number of mismatches from ref. sequence
				{
					if(tag >= TAG_SEQ_REF_SEL && tag < TAG_SEQ_AUG)
						col_id = (tag - TAG_SEQ_REF_SEL) / 2 + 1;

					offset += pos;
					seq_decomp.PutBytes(refs[col_id]->raw_seq_ref+(int64)1+offset, lens[0]);
					int64 s_pos = 0;
					for(int32 j = 1; j < lens.size(); ++j)
					{
						s_pos += lens[j-1];
						if(lit_coding[chars[j-1]] < lit_coding[refs[col_id]->raw_seq_ref[offset+(int64)1+s_pos]])
							seq_decomp.PutByte(chars[j-1]);
						else
							seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
						s_pos++;
						seq_decomp.PutBytes(refs[col_id]->raw_seq_ref+(int64)1+offset+s_pos, lens[j]);
					}
					last_exc_char = refs[col_id]->raw_seq_ref[offset+(int64)1+s_pos+(int64) lens.back()];
				}
				pos += (uint32) (accumulate(lens.begin(), lens.end(), (uint32) 0) + (uint32) lens.size() - 1);
			}
			else
// *** Invalid flag
			{
				cout << "Invalid flag: " << (int) flag << "\n";
				return false;
			}
			last_flag = flag;
		}
	}

	return true;
}

// ********************************************************************************************
bool CSequence::UnProcessRA(uint32 extr_size)
{
	uchar c1;
	int64 offset;
	int32 len1;
	uchar tag;

	seq_decomp.Create(extr_size+32);
	seq_decomp.PutByte(' ');
	uint32 pos = 1;
	vector<uchar> chars;
	vector<int32> lens;
	uchar last_exc_char = ' ';
	uint32 col_id = 1;
	uint32 prev_col_id = 1;
	uint32 k, k_stop;

	uint32 block_sft = refs[1]->block_size_exp;
	uint32 block_msk = (1 << block_sft) - 1;

	pos = block_starts[extr_b_start];
	for(int32 i = extr_b_start; i <= extr_b_end; ++i)
	{
		if(pos > extr_to)
			break;

		blocks[i]->StartGetFlag();
		t_flag last_flag = 0;
		last_exc_char = ' ';
		for(t_flag flag = blocks[i]->GetFlag(); flag != N_FLAGS; flag = blocks[i]->GetFlag())
		{
			if(flag == 0)
// *** Single literal
			{
				blocks[i]->GetLiteral(c1);
				if(pos >= extr_from)
				{
					if(last_flag > 0 && last_flag < N_FLAGS-1)
					{					
						if(lit_coding[c1] < lit_coding[last_exc_char])
							seq_decomp.PutByte(c1);
						else
							seq_decomp.PutByte(alph[lit_coding[c1]+1]);
					}
					else
						seq_decomp.PutByte(c1);
				}
				++pos;
				last_exc_char = ' ';
			}
			else if(flag == 1)
// *** Match witout mismatches or pseudomatch
			{
				blocks[i]->GetMatch(tag, offset, len1);
				if(tag == TAG_PSEUDO_MATCH_N || tag == TAG_PSEUDO_MATCH_n)
// *** Run of N's or n's
				{
					char cur_char;
					if(tag == TAG_PSEUDO_MATCH_N)
						cur_char = 'N';
					else
						cur_char = 'n';
					if((int64)pos+(int64) len1 > extr_to)
						len1 = (int32) (extr_to-(int64)pos+(int64)1);
					if(pos >= extr_from)
						seq_decomp.PutNBytes(cur_char, len1);
					else if((int64) pos + (int64) len1 > extr_from)
						seq_decomp.PutNBytes(cur_char, (int32) ((int64) pos + (int64) len1 - extr_from));
					last_exc_char = cur_char;
					pos += (uint32) len1;
				}
				else
// *** Match without mismatches
				{
					if(tag == TAG_SEQ_AUG)
  // *** Match in aug. sequence
					{
						if((int64) pos + (int64) len1 > extr_from)
						{
							CReference *cur_ref = refs[0];
							if(pos >= extr_from)
								k = (uint32) offset;
							else
							{
								k = (uint32) (offset + extr_from - (int64) pos);
								pos = (uint32) extr_from;
							}
							k_stop = (uint32) (offset+len1);
							if((int64) pos + (int64) k_stop - (int64) k > extr_to)
								k_stop = (uint32) (extr_to - (int64) pos + (int64) k + 1);

							pos += (uint32) (k_stop - k);
							if(cur_ref->compress_mode == 1)
							{
								cur_ref->DecompressRange(k, k_stop+1);
								for(; k < k_stop; ++k)
									seq_decomp.PutByte(refs[0]->blocks[k >> block_sft].seq_comp[k & block_msk]);
							}
							else
							{
								cur_ref->StartGetSymbol(k);
								for(; k < k_stop; ++k)
									seq_decomp.PutByte(cur_ref->GetSymbol());
							}
						}
						else
							pos += (uint32) len1;
						last_exc_char = ' ';
					}
					else
  // *** Match in ref. sequence
					{
						offset += pos;

						if((int64) pos + (int64) len1 > extr_from)
						{
							CReference *cur_ref = refs[1];
							assert(offset >= 0 && offset < cur_ref->seq_ref_size);

							if(cur_ref->compress_mode == 1)
	// *** Slow compression
							{
								if(pos >= extr_from)
									k = (uint32) (offset-1);
								else
								{
									k = (uint32) (offset-1 + extr_from - (int64) pos);
									pos = (uint32) extr_from;
								}
								k_stop = (uint32) (offset-(int64)1+(int64)len1);
								if((int64) pos + (int64) k_stop - (int64) k > extr_to)
									k_stop = (uint32) (extr_to - (int64) pos + (int64) k + 1);

								pos += k_stop - k;
								cur_ref->DecompressRange(k, k_stop+1);
								for(; k < k_stop; ++k)
									seq_decomp.PutByte(cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]);
								last_exc_char = cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk];
							}
							else
	// *** Fast compression
							{
								if((int64) pos >= extr_from)
									k = (uint32) offset;
								else
								{
									k = (uint32) (offset + extr_from - (int64) pos);
									pos = (uint32) extr_from;
								}
								k_stop = (uint32) (offset+len1);
								if((int64) pos + (int64) k_stop - (int64) k > extr_to)
									k_stop = (uint32) (extr_to - (int64) pos + (int64) k + 1);

								pos += k_stop - k;
								cur_ref->StartGetSymbol(k);
								for(; k < k_stop; ++k)
									seq_decomp.PutByte(cur_ref->GetSymbol());
								last_exc_char = cur_ref->GetSymbol();
							}
						}
						else
							pos += (uint32) len1;
					}
				}
			}
			else if(flag == N_LIT)
// *** Many literals
			{
				blocks[i]->GetLiterals(chars);
				uint32 len = (uint32) chars.size();
				uint32 j, j_stop;

				if((int64) pos + (int64) len >= extr_from)
				{
					j = 0;
					if(last_flag > 0 && last_flag < N_FLAGS-1)
					{					
						if(pos++ >= extr_from)
						{
							if(lit_coding[chars[0]] < lit_coding[last_exc_char])
								seq_decomp.PutByte(chars[0]);
							else
								seq_decomp.PutByte(alph[lit_coding[chars[0]]+1]);
						}
						j = 1;
					}

					if(pos < extr_from)
					{
						j += (uint32) (extr_from - (int64) pos);
						pos = (uint32) extr_from;
					}
					if((int64) pos + (int64) len - (int64) j > extr_to)
						j_stop = (uint32) ((int64) j + extr_to - (int64) pos + 1);
					else
						j_stop = len;

					pos += j_stop - j;
					for(; j < j_stop; ++j)
						seq_decomp.PutByte(chars[j]);
				}
				else
					pos += len;

				last_exc_char = ' ';
			}
			else if(flag < N_MISMATCHES+2)
// *** Match with many mismatches
			{
				blocks[i]->GetMatch(flag, tag, offset, lens, chars);
				int32 m_len = (int32) (accumulate(lens.begin(), lens.end(), lens.size()-1));
				if(tag == TAG_SEQ_AUG)
  // *** Match in aug. sequence
				{
					CReference *cur_ref = refs[0];
					if(cur_ref->compress_mode == 1)
    // *** Slow compression mode
					{
						if(pos + m_len > extr_from)
						{
							cur_ref->DecompressRange((uint32) offset, (uint32) (offset+m_len));
							for(k = (uint32) offset; k < (uint32) (offset+lens[0]); ++k)
								if(pos++ >= extr_from)
									seq_decomp.PutByte(cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]);
							uint32 s_pos = 0;
							for(int32 j = 1; j < (int32) lens.size(); ++j)
							{
								s_pos += lens[j-1];
								if(pos++ >= (uint32) extr_from)
								{
									if(lit_coding[chars[j-1]] < lit_coding[cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]])
										seq_decomp.PutByte(chars[j-1]);
									else
										seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
								}
								k++;
								s_pos++;
								uint32 max_k = k + lens[j];
								for(; k < max_k; ++k)
									if(pos++ >= (uint32) extr_from)
									{
										seq_decomp.PutByte(cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]);
										if(pos > extr_to)
											break;
									}
							}
						}
						else
							pos += (uint32) m_len;
					}
					else
	// *** Fast compression mode
					{
						if((int64) pos + (int64) m_len > extr_from)
						{
							cur_ref->StartGetSymbol((uint32) (offset-1));
							for(k = (uint32) offset; k < (uint32) (offset+lens[0]); ++k)
								if(pos++ >= (uint32) extr_from)
									seq_decomp.PutByte(cur_ref->GetSymbol());
								else
									cur_ref->GetSymbol();
							uint32 s_pos = 0;
							for(int32 j = 1; j < lens.size(); ++j)
							{
								s_pos += lens[j-1];
								if(pos++ >= extr_from)
								{
									if(lit_coding[chars[j-1]] < lit_coding[cur_ref->GetSymbol()])
										seq_decomp.PutByte(chars[j-1]);
									else
										seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
								}
								else
									cur_ref->GetSymbol();
								k++;
								s_pos++;
								uint32 max_k = k + lens[j];
								for(; k < max_k; ++k)
									if(pos++ >= (uint32) extr_from)
									{
										seq_decomp.PutByte(cur_ref->GetSymbol());
										if(pos > (uint32) extr_to)
											break;
									}
									else
										cur_ref->GetSymbol();
							}
						}
						else
							pos += (uint32) m_len;
					}
					last_exc_char = ' ';
				}
				else
  // *** Match in ref. sequence
				{
					offset += pos;
					if((int64) pos + (int64) m_len > extr_from)
					{
						CReference *cur_ref = refs[1];
						if(cur_ref->compress_mode == 1)
	// *** Slow compression mode
						{
							if(pos+lens[0] >= extr_from)
							{
								if(pos >= (uint32) extr_from)
									k = (uint32) (offset-1);
								else
								{
									k = (uint32) (offset-1 + extr_from - (int64) pos);
									pos = (uint32) extr_from;
								}
								uint32 max_k = (uint32) (offset-1+(int64)lens[0]);
								if((int64) pos + (int64) max_k - (int64) k > extr_to)
									max_k = (uint32) (extr_to - (int64) pos + (int64) k + 1);

								cur_ref->DecompressRange(k, max_k+1);
								pos += max_k - k;

								for(; k < max_k; ++k)
									seq_decomp.PutByte(cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]);
							}
							else
							{
								pos += (uint32) lens[0];
								k = (uint32) (offset-1+(int64)lens[0]);
							}
							uint32 s_pos = 0;
							for(int32 j = 1; j < lens.size(); ++j)
							{
								s_pos += lens[j-1];
								if(pos++ >= (uint32) extr_from)
								{
									cur_ref->DecompressRange(k, k+1);
									if(lit_coding[chars[j-1]] < lit_coding[refs[col_id]->blocks[k >> block_sft].seq_comp[k & block_msk]])
										seq_decomp.PutByte(chars[j-1]);
									else
										seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
								}
								s_pos++;
								k++;
								uint32 max_k = k + (uint32) lens[j];

								if(pos > (uint32) extr_to)
									return true;

								if((int64) pos + (int64) lens[j] > extr_from)
								{
									if(pos < (uint32) extr_from)
									{
										k += (uint32) (extr_from - (int64) pos);
										pos = (uint32) (extr_from);
									}
									if((int64) pos + (int64) max_k - (int64) k > extr_to)
										max_k = (uint32) (extr_to - (int64) pos + (int64) k + 1);
									pos += max_k - k;

									cur_ref->DecompressRange(k, max_k+1);
									for(; k < max_k; ++k)
										seq_decomp.PutByte(cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk]);
								}
								else
								{
									pos += (uint32) lens[j];
									k += (uint32) lens[j];
								}
							}
							last_exc_char = cur_ref->blocks[k >> block_sft].seq_comp[k & block_msk];
						}
						else
	// *** Fast compression mode
						{
							cur_ref->StartGetSymbol((uint32) offset);
							if((int64) pos + (int64) lens[0] >= extr_from)
							{
								if(pos >= (uint32) extr_from)
									k = (uint32) offset;
								else
								{
									k = (uint32) (offset + extr_from - (int64) pos);
									pos = (uint32) extr_from;
								}
								cur_ref->StartGetSymbol(k);
								uint32 max_k = (uint32) (offset+(int64)lens[0]);

								if((int64) pos + (int64) max_k - (int64) k > extr_to)
									max_k = (uint32) (extr_to - (int64) pos + (int64) k + 1);
								pos += max_k - k;
								for(; k < max_k; ++k)
									seq_decomp.PutByte(cur_ref->GetSymbol());
							}
							else
							{
								cur_ref->SkipSymbols(lens[0]);
								pos += (uint32) lens[0];
								k = (uint32) (offset+(int32)lens[0]);
							}
							uint32 s_pos = 0;
							for(int32 j = 1; j < lens.size(); ++j)
							{
								s_pos += lens[j-1];
								if(pos++ >= (uint32) extr_from)
								{
									if(lit_coding[chars[j-1]] < lit_coding[cur_ref->GetSymbol()])
										seq_decomp.PutByte(chars[j-1]);
									else
										seq_decomp.PutByte(alph[lit_coding[chars[j-1]]+1]);
								}
								else
									cur_ref->GetSymbol();
								s_pos++;
								k++;
								uint32 max_k = k + lens[j];

								if(pos > (uint32) extr_to)
									return true;
								if(pos + lens[j] > (uint32) extr_from)
								{
									if(pos < (uint32) extr_from)
									{
										k += (uint32) (extr_from - (int64) pos);
										cur_ref->SkipSymbols((uint32) (extr_from - (int64) pos));
										pos = (uint32) extr_from;
									}
									if(pos + (int64) max_k - (int64) k > extr_to)
										max_k = (uint32) (extr_to - (int64) pos + (int64) k + 1);
									pos += max_k - k;
									for(; k < max_k; ++k)
										seq_decomp.PutByte(cur_ref->GetSymbol());
								}
								else
								{
									cur_ref->SkipSymbols(lens[j]);
									pos += (uint32) lens[j];
									k += (uint32) lens[j];
								}
							}
							last_exc_char = cur_ref->GetSymbol();
						}
					}
					else
						pos += (uint32) m_len;
				}
			}
			else
// *** Illegal flag
			{
				cout << "Invalid flag: " << (int) flag << "\n";
				return false;
			}
			last_flag = flag;
			if(pos > extr_to)
				break;
		}
	}

	return true;
}

// ********************************************************************************************
bool CSequence::Decompress()
{
	uint32 i;

	extr_from = -1;
	extr_to   = -1;

	for(i = 0; i < blocks.size(); ++i)
	{
		blocks[i]->SetHuffmans(&huf_flags, &huf_literals, &huf_lens, &huf_offsets);
		blocks[i]->Decompress();
	}

	return true;
}

// ********************************************************************************************
bool CSequence::DecompressRange(int64 from, int64 to)
{
	int32 i;
	extr_from = from;
	extr_to   = to;

	vector<uint32>::iterator p = lower_bound(block_starts.begin(), block_starts.end(), (uint32) (from+1));
	extr_b_start = (int32) (p - block_starts.begin() - 1);
	vector<uint32>::iterator q;
	
	q = upper_bound(block_starts.begin(), block_starts.end(), (uint32) (to+1));
	extr_b_end = (int32) (q - block_starts.begin() - 1);

	InitBlocks(extr_b_start, extr_b_end);

	if(refs[0])
		refs[0]->StartRead();
	if(refs[1])
		refs[1]->StartRead();

	for(i = extr_b_start; i <= extr_b_end; ++i)
	{
		blocks[i]->SetHuffmans(&huf_flags, &huf_literals, &huf_lens, &huf_offsets);
		blocks[i]->Decompress();
	}

	return true;
}

// ********************************************************************************************
bool CSequence::Store(uchar *&buffer, uint32 &size)
{
	uint32 i, tmp;

	// Calculate memory occupation
	size = 0;
	size += sizeof(uint32);
	size += (int32) (block_starts.size()+1) * 2 * sizeof(int32) + 2 * sizeof(uchar);
 	
	for(i = 0; i < blocks.size(); ++i)
//		size += (int32) blocks[i]->bit_memory->mem_buffer_pos + sizeof(int64);
		size += (int32) blocks[i]->bit_memory->mem_buffer_pos + sizeof(int32);

	uchar *buf_flags;
	uchar *buf_literals;
	uchar *buf_lens[2];
	uchar *buf_offsets[5];
	uint32 len_flags;
	uint32 len_literals;
	uint32 len_lens[2];
	uint32 len_offsets[5] = {0};
	huf_flags.StoreTree(buf_flags, len_flags);
	huf_literals.StoreTree(buf_literals, len_literals);
	for(i = 0; i < S_LENS; ++i)
		huf_lens[i].StoreTree(buf_lens[i], len_lens[i]);
	for(i = 0; i < S_OFFSETS; ++i)
		huf_offsets[i].StoreTree(buf_offsets[i], len_offsets[i]);
	size += 2 * sizeof(uchar) + (S_LENS + S_OFFSETS) * sizeof(uint32);

	size += len_flags + len_literals;
	for(i = 0; i < S_LENS; ++i)
		size += len_lens[i];
	for(i = 0; i < S_OFFSETS; ++i)
		size += len_offsets[i];
	size += sizeof(uint32);

	size += (sigma+1) * sizeof(uchar);

	// Store data
	buffer = new uchar[size];
	uint32 pos = 0;

	memcpy(buffer+pos, &size, sizeof(size));						pos += sizeof(size);
	tmp = (uint32) block_starts.size();
	memcpy(buffer+pos, &tmp, sizeof(uint32));						pos += sizeof(uint32);
	for(i = 0; i < block_starts.size(); ++i)
	{
		memcpy(buffer+pos, &block_starts[i], sizeof(int32));		pos += sizeof(uint32);	
	}
	for(i = 0; i < blocks.size(); ++i)
	{
		uint32 tmp = (uint32) blocks[i]->bit_memory->mem_buffer_pos;
//		memcpy(buffer+pos, &blocks[i]->bit_memory->mem_buffer_pos, sizeof(int64));
		memcpy(buffer+pos, &tmp, sizeof(uint32));
//		pos += sizeof(int64);
		pos += sizeof(uint32);
	}
	buffer[pos++] = (uchar) P_FLAG_MAX_EXP;
	buffer[pos++] = (uchar) P_LIT_MAX_EXP;
	buffer[pos++] = (uchar) S_LENS;
	buffer[pos++] = (uchar) S_OFFSETS;
	memcpy(buffer+pos, &len_flags, sizeof(uint32));					pos += sizeof(uint32);
	memcpy(buffer+pos, buf_flags, len_flags);						pos += len_flags;
	memcpy(buffer+pos, &len_literals, sizeof(uint32));				pos += sizeof(uint32);
	memcpy(buffer+pos, buf_literals, len_literals);					pos += len_literals;
	for(i = 0; i < S_LENS; ++i)
	{
		memcpy(buffer+pos, &len_lens[i], sizeof(uint32));			pos += sizeof(uint32);
		memcpy(buffer+pos, buf_lens[i], len_lens[i]);				pos += len_lens[i];
	}
	for(i = 0; i < S_OFFSETS; ++i)
	{
		memcpy(buffer+pos, &len_offsets[i], sizeof(uint32));		pos += sizeof(uint32);
		memcpy(buffer+pos, buf_offsets[i], len_offsets[i]);			pos += len_offsets[i];
	}

	buffer[pos] = sigma;											pos++;
	for(i = 0; i < sigma; ++i)
		buffer[pos++] = alph[i];
		
	for(i = 0; i < blocks.size(); ++i)
	{
		memcpy(buffer+pos, blocks[i]->bit_memory->mem_buffer, blocks[i]->bit_memory->mem_buffer_pos);
		pos += (int32) blocks[i]->bit_memory->mem_buffer_pos;
	}

	return true;
}

// ********************************************************************************************
bool CSequence::Load(uchar *buffer, uint32 size)
{
	uint32 pos = 0;
	uint32 i;
	int64 tmp64;
	uint32 tmp32;
	uint32 n_blck;

	memcpy(&seq_size, buffer+pos, sizeof(seq_size));				pos += sizeof(seq_size);
	memcpy(&n_blck, buffer+pos, sizeof(uint32));					pos += sizeof(uint32);
	for(i = 0; i < n_blck; ++i)
	{
		memcpy(&tmp32, buffer+pos, sizeof(uint32));					pos += sizeof(uint32);
		block_starts.push_back(tmp32);
	}
	compact_vector(block_starts);

	for(i = 0; i < n_blck; ++i)
	{
//		memcpy(&tmp64, buffer+pos, sizeof(int64));
		memcpy(&tmp32, buffer+pos, sizeof(uint32));
//		block_sizes.push_back((int32) tmp64);
		block_sizes.push_back(tmp32);
//		pos += sizeof(int64);
		pos += sizeof(uint32);
	}
	compact_vector(block_sizes);

	P_FLAG_MAX_EXP = buffer[pos++];
	P_LIT_MAX_EXP  = buffer[pos++];
	P_FLAG_MAX     = 1 << P_FLAG_MAX_EXP;
	P_LIT_MAX      = 1 << P_LIT_MAX_EXP;
	pbf->Init(P_FLAG_MAX);
	pbl->Init(P_LIT_MAX);
	S_LENS         = buffer[pos++];
	S_OFFSETS      = buffer[pos++];

	uint32 len_flags;
	memcpy(&len_flags, buffer+pos, sizeof(uint32));					pos += sizeof(uint32);
	huf_flags.LoadTree(buffer+pos, len_flags);						pos += len_flags;

	uint32 len_literals;
	memcpy(&len_literals, buffer+pos, sizeof(uint32));				pos += sizeof(uint32);
	huf_literals.LoadTree(buffer+pos, len_literals);				pos += len_literals;
	
	uint32 len_lens[2];
	huf_lens.resize(S_LENS);
	for(i = 0; i < S_LENS; ++i)
	{
		memcpy(&len_lens[i], buffer+pos, sizeof(uint32));			pos += sizeof(uint32);
		huf_lens[i].LoadTree(buffer+pos, len_lens[i]);				pos += len_lens[i];
	}

	uint32 len_offsets[5];
	huf_offsets.resize(S_OFFSETS);
	for(i = 0; i < S_OFFSETS; ++i)
	{
		memcpy(&len_offsets[i], buffer+pos, sizeof(uint32));		pos += sizeof(uint32);
		huf_offsets[i].LoadTree(buffer+pos, len_offsets[i]);		pos += len_offsets[i];
	}
	
	sigma = buffer[pos];											pos++;
	fill_n(lit_coding, 256, 255);
	for(i = 0; i < sigma; ++i)
	{
		alph[i] = buffer[pos++];
		lit_coding[alph[i]] = i;
	}

	blocks.resize(n_blck);
	for(i = 0; i < n_blck; ++i)
		blocks[i] = NULL;

	comp_seq = buffer;

	block_comp_starts.clear();
	for(i = 0; i < n_blck; ++i)
	{
		block_comp_starts.push_back(pos);
		pos += block_sizes[i];
	}
	compact_vector(block_comp_starts);

	return true;
}

// ********************************************************************************************
bool CSequence::InitBlocks(int32 b_from, int32 b_to)
{
	uint32 pos; 
	int32 i;

	if(b_from == -1)
	{
		b_from = 0;
		b_to = (int32) blocks.size()-1;
	}

	pos = (uint32) block_comp_starts[b_from];

	for(i = b_from; i <= b_to; ++i)
	{
		blocks[i] = new CBlock();
		blocks[i]->P_FLAG_MAX = P_FLAG_MAX;
		blocks[i]->P_LIT_MAX  = P_LIT_MAX;
		blocks[i]->S_LENS	 = S_LENS;
		blocks[i]->S_OFFSETS	 = S_OFFSETS;
		blocks[i]->Open(comp_seq+pos, block_sizes[i]);
		blocks[i]->SetParams(min_match_1st_len, min_match_ext_len, block_size_exp, pbf, pbl);
		blocks[i]->sigma = sigma;
		blocks[i]->alph = alph;
		blocks[i]->lit_coding = lit_coding;
		blocks[i]->seq_start_block = block_starts[i];
		pos += block_sizes[i];
	}

	return true;
}

// ********************************************************************************************
bool CSequence::Release()
{
	if(extr_b_start >= 0)
		for(int i = extr_b_start; i <= extr_b_end; ++i)
		{
			delete blocks[i];
			blocks[i] = NULL;
		}

	seq_decomp.Close();

	return true;
}
